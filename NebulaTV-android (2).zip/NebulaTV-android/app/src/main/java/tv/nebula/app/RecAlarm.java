package tv.nebula.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Starts a scheduled recording when its timer fires, and restores timers after a restart or app update. */
public class RecAlarm extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            RecordService.rescheduleAll(ctx);
            return;
        }
        String id = intent == null ? null : intent.getStringExtra("id");
        if (id != null) RecordService.startNow(ctx, id);
    }
}
