package tv.nebula.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;

/** The live TV buffer, against a little local server pretending to be an IPTV provider. */
public class TimeshiftTest {
    private static String base;
    private static final long T0 = System.currentTimeMillis();
    private File dir;
    private Timeshift ts;

    /** A tiny web server using only java.net, because Android builds compile tests without the JDK's own server. */
    interface Handler { void handle(String path, OutputStream out) throws Exception; }

    private static ServerSocket sock;

    private static void reply(OutputStream o, String status, String type, byte[] body, String extra) throws Exception {
        String h = "HTTP/1.1 " + status + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.length
                + "\r\nConnection: close\r\n" + (extra == null ? "" : extra) + "\r\n";
        o.write(h.getBytes("UTF-8"));
        o.write(body);
        o.flush();
    }

    private static final Handler ROUTES = (path, o) -> {
        if (path.startsWith("/live.ts")) {
            o.write("HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\nConnection: close\r\n\r\n".getBytes("UTF-8"));
            byte[] p = new byte[188 * 100];
            for (int i = 0; i < p.length; i += 188) p[i] = 0x47;
            while (true) { o.write(p); o.flush(); Thread.sleep(94); }   // about 200 KB/s, until the client hangs up
        } else if (path.startsWith("/hls/index.m3u8")) {
            long n = (System.currentTimeMillis() - T0) / 1000;
            StringBuilder b = new StringBuilder("#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:" + n + "\n");
            for (long i = n; i < n + 4; i++) b.append("#EXTINF:1.0,\nseg").append(i).append(".ts\n");
            reply(o, "200 OK", "application/vnd.apple.mpegurl", b.toString().getBytes("UTF-8"), null);
        } else if (path.startsWith("/hls/")) {
            byte[] d = new byte[188 * 500];
            for (int i = 0; i < d.length; i += 188) d[i] = 0x47;
            reply(o, "200 OK", "video/mp2t", d, null);
        } else if (path.startsWith("/enc/index.m3u8")) {
            reply(o, "200 OK", "application/vnd.apple.mpegurl",
                    "#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:1.0,\na.ts\n".getBytes("UTF-8"), null);
        } else if (path.startsWith("/redir.ts")) {
            reply(o, "302 Found", "text/plain", new byte[0], "Location: /live.ts\r\n");
        } else {
            reply(o, "404 Not Found", "text/plain", new byte[0], null);
        }
    };

    @BeforeClass
    public static void startServer() throws Exception {
        sock = new ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
        Thread accept = new Thread(() -> {
            while (!sock.isClosed()) {
                try {
                    final Socket c = sock.accept();
                    Thread t = new Thread(() -> {
                        try (Socket s2 = c) {
                            BufferedReader in = new BufferedReader(new InputStreamReader(s2.getInputStream(), "UTF-8"));
                            String line = in.readLine();
                            if (line == null) return;
                            String[] parts = line.split(" ");
                            String path = parts.length > 1 ? parts[1] : "/";
                            String h;
                            while ((h = in.readLine()) != null && !h.isEmpty()) { /* skip the request headers */ }
                            ROUTES.handle(path, s2.getOutputStream());
                        } catch (Exception ignored) {
                        }
                    });
                    t.setDaemon(true);
                    t.start();
                } catch (Exception e) {
                    return;
                }
            }
        });
        accept.setDaemon(true);
        accept.start();
        base = "http://127.0.0.1:" + sock.getLocalPort();
    }

    @AfterClass
    public static void stopServer() throws Exception { sock.close(); }

    @Before
    public void setUp() throws Exception {
        dir = Files.createTempDirectory("nebula-ts").toFile();
        Timeshift.CHUNK_BYTES = 8L * 1024 * 1024;
        Timeshift.MIN_MS = 60_000L;
        Timeshift.MIN_BYTES = 64L * 1024 * 1024;
    }

    @After
    public void tearDown() {
        if (ts != null) ts.stop();
    }

    @Test
    public void buffersAPlainStreamThroughARedirect() throws Exception {
        ts = new Timeshift(base + "/redir.ts", "TestAgent", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(2500);
        assertTrue("bytes buffered: " + ts.written(), ts.written() > 200_000);
        assertTrue(ts.error(), !ts.failed());
        byte[] buf = new byte[65536];
        int r = ts.read(0, buf, 0, buf.length);
        assertTrue(r > 0);
        assertEquals(0x47, buf[0]);
    }

    @Test
    public void mapsTimesToPositionsAndBack() throws Exception {
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(3000);
        long wall = System.currentTimeMillis() - 1500;
        long off = ts.offsetAt(wall);
        assertTrue("offset " + off + " of " + ts.written(), off > 0 && off < ts.written());
        assertTrue(Math.abs(ts.wallAt(off) - wall) < 700);
    }

    @Test
    public void readingPastTheEdgeWaitsForMore() throws Exception {
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(1500);
        long t = System.currentTimeMillis();
        int r = ts.read(ts.written() + 40_000, new byte[1000], 0, 1000);
        assertTrue(r > 0);
        assertTrue("waited " + (System.currentTimeMillis() - t) + "ms", System.currentTimeMillis() - t >= 100);
    }

    @Test
    public void dropsOldChunksOutsideTheWindow() throws Exception {
        Timeshift.CHUNK_BYTES = 100_000;
        Timeshift.MIN_MS = 1000;
        Timeshift.MIN_BYTES = 1;
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 2000, 10L << 20);
        ts.start();
        Thread.sleep(5000);
        assertTrue(ts.earliestOffset() > 0);
        assertTrue(System.currentTimeMillis() - ts.earliestWall() < 4000);
        assertEquals(-2, ts.read(0, new byte[100], 0, 100));
        File[] left = dir.listFiles();
        assertTrue(left != null && left.length <= 10);
    }

    @Test
    public void keepsWithinTheSpaceAllowance() throws Exception {
        Timeshift.CHUNK_BYTES = 100_000;
        Timeshift.MIN_BYTES = 1;
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 300_000);
        ts.start();
        Thread.sleep(4000);
        assertTrue(ts.written() - ts.earliestOffset() <= 500_000);
    }

    @Test
    public void buffersHls() throws Exception {
        ts = new Timeshift(base + "/hls/index.m3u8", "", "hls", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(3500);
        assertTrue("HLS bytes: " + ts.written(), ts.written() >= 188 * 500 * 3);
        assertEquals("", ts.error());
    }

    @Test
    public void refusesEncryptedHls() throws Exception {
        ts = new Timeshift(base + "/enc/index.m3u8", "", "hls", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(1500);
        assertTrue(ts.failed());
        assertTrue(ts.error(), ts.error().contains("encrypted"));
    }

    @Test
    public void reportsADeadChannel() throws Exception {
        ts = new Timeshift(base + "/dead.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(6000);
        assertTrue(ts.failed());
        assertTrue(ts.error(), ts.error().contains("404"));
    }

    @Test
    public void stopDeletesTheBufferAndEndsReads() throws Exception {
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(1500);
        ts.stop();
        File[] left = dir.listFiles();
        assertTrue(left == null || left.length == 0);
        assertEquals(-1, ts.read(0, new byte[10], 0, 10));
    }
}
