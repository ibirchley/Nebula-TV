package tv.nebula.app;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The web app talks to Android through NATIVE.something(...). A call to a method that doesn't exist,
 * or with the wrong number of arguments, silently fails on the TV, so check every call here.
 */
public class BridgeTest {
    private static String read(String path) throws Exception {
        File f = new File(path);
        if (!f.exists()) f = new File("app/" + path);   // run from the project folder or the app folder
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }

    /** Counts the arguments in a call, starting just after its opening bracket. */
    static int countArgs(String s, int i) {
        int depth = 0, commas = 0;
        char quote = 0;
        boolean empty = true;
        for (; i < s.length(); i++) {
            char c = s.charAt(i);
            if (quote != 0) {
                if (c == '\\') { i++; continue; }
                if (c == quote) quote = 0;
            } else if (c == '\'' || c == '"' || c == '`') { quote = c; empty = false; }
            else if (c == '(' || c == '[' || c == '{') { depth++; empty = false; }
            else if (c == ')' || c == ']' || c == '}') {
                if (depth == 0) return empty ? 0 : commas + 1;
                depth--;
            } else if (c == ',' && depth == 0) commas++;
            else if (!Character.isWhitespace(c)) empty = false;
        }
        return -1;
    }

    @Test
    public void everyNativeCallExistsWithTheRightArguments() throws Exception {
        String js = read("src/main/assets/index.html");
        String java = read("src/main/java/tv/nebula/app/MainActivity.java");
        Map<String, Set<Integer>> bridge = new HashMap<>();
        Matcher m = Pattern.compile("@JavascriptInterface\\s+public\\s+[\\w<>\\[\\]]+\\s+(\\w+)\\s*\\(([^)]*)\\)").matcher(java);
        while (m.find()) {
            String p = m.group(2).trim();
            int n = p.isEmpty() ? 0 : p.split(",").length;
            bridge.computeIfAbsent(m.group(1), k -> new HashSet<>()).add(n);
        }
        assertTrue("no bridge methods found", bridge.size() > 20);
        List<String> problems = new ArrayList<>();
        Matcher c = Pattern.compile("NATIVE\\.(\\w+)\\(").matcher(js);
        while (c.find()) {
            String name = c.group(1);
            int n = countArgs(js, c.end());
            if (!bridge.containsKey(name)) problems.add("NATIVE." + name + " is not an Android method");
            else if (!bridge.get(name).contains(n)) problems.add("NATIVE." + name + " is called with " + n + " arguments but takes " + bridge.get(name));
        }
        // methods only checked for, like NATIVE&&NATIVE.tsPause, must exist too
        Matcher q = Pattern.compile("NATIVE&&NATIVE\\.(\\w+)").matcher(js);
        while (q.find()) if (!bridge.containsKey(q.group(1))) problems.add("NATIVE." + q.group(1) + " is checked for but missing");
        assertTrue(String.join("\n", problems), problems.isEmpty());
    }

    @Test
    public void webAppIsComplete() throws Exception {
        String js = read("src/main/assets/index.html");
        int last = js.lastIndexOf("</script>");
        assertTrue("no closing script tag", last > 0);
        String tail = js.substring(last + 9).replaceAll("\\s+", "");
        assertTrue("unexpected text after the app script: " + tail, tail.equals("</body></html>"));
        assertTrue("the app script looks cut short", js.contains("window.nebulaKey=") && js.contains("(async function boot(){"));
    }
}
