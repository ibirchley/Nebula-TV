package tv.nebula.app;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The live TV buffer: one connection copies the channel into short chunk files, and the player
 * reads them back, so live TV can be paused, rewound and skipped forward like a set top box.
 * Old chunks are deleted once they fall outside the buffer window or the space allowance.
 */
final class Timeshift {
    // limits (not final so the tests can shrink them)
    static long CHUNK_BYTES = 8L * 1024 * 1024, MIN_MS = 60_000L, MIN_BYTES = 64L * 1024 * 1024;

    private static final class Chunk {
        final long start;      // offset of the chunk's first byte in the whole buffer
        final File file;
        volatile long len;
        final long wall;       // when its first byte arrived
        Chunk(long start, File file, long wall) { this.start = start; this.file = file; this.wall = wall; }
    }

    final String url, ua, type;
    private final File dir;
    private final long maxMs, maxBytes;
    private final List<Chunk> chunks = new ArrayList<>();
    private final List<long[]> marks = new ArrayList<>();   // {wall time, offset}
    private volatile long written = 0;
    private volatile boolean stop = false, done = false;
    private volatile String error = "";
    private volatile long firstData = 0;
    final long started = System.currentTimeMillis();
    private Thread thread;

    Timeshift(String url, String ua, String type, File dir, long maxMs, long maxBytes) {
        this.url = url;
        this.ua = ua == null ? "" : ua;
        this.type = type == null ? "" : type;
        this.dir = dir;
        this.maxMs = Math.max(MIN_MS, maxMs);
        this.maxBytes = Math.max(MIN_BYTES, maxBytes);
    }

    void start() {
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();
        thread = new Thread(this::run, "nebula-timeshift");
        thread.setDaemon(true);
        thread.start();
    }

    void stop() {
        stop = true;
        if (thread != null) thread.interrupt();
        synchronized (this) {
            for (Chunk c : chunks) c.file.delete();
            chunks.clear();
            marks.clear();
            notifyAll();
        }
    }

    boolean stopped() { return stop; }
    boolean failed() { return done && written == 0; }
    String error() { return error; }
    long written() { return written; }
    long firstData() { return firstData; }

    /** The oldest point still in the buffer, as a wall-clock time. */
    synchronized long earliestWall() {
        return chunks.isEmpty() ? System.currentTimeMillis() : chunks.get(0).wall;
    }

    synchronized long earliestOffset() {
        return chunks.isEmpty() ? 0 : chunks.get(0).start;
    }

    /** Where in the buffer the stream was at a given wall-clock time. */
    synchronized long offsetAt(long wall) {
        long best = earliestOffset();
        for (long[] m : marks) {
            if (m[0] <= wall) best = m[1];
            else break;
        }
        return Math.max(best, earliestOffset());
    }

    /** The wall-clock time a given offset was received. */
    synchronized long wallAt(long offset) {
        long best = earliestWall();
        for (long[] m : marks) {
            if (m[1] <= offset) best = m[0];
            else break;
        }
        return best;
    }

    // ---------- reading (the player's side) ----------

    /**
     * Reads from the buffer, waiting for more of the channel to arrive when it has caught up.
     * Returns -1 once the buffer has stopped and everything has been read.
     */
    int read(long pos, byte[] buf, int off, int len) throws IOException {
        long waited = 0;
        while (true) {
            if (stop) return -1;
            Chunk c = null;
            synchronized (this) {
                if (!chunks.isEmpty() && pos < chunks.get(0).start) return -2;   // that part has been dropped
                for (int i = chunks.size() - 1; i >= 0; i--) {
                    Chunk x = chunks.get(i);
                    if (pos >= x.start && pos < x.start + x.len) { c = x; break; }
                }
            }
            if (c != null) {
                long at = pos - c.start;
                int n = (int) Math.min(len, c.len - at);
                try (RandomAccessFile f = new RandomAccessFile(c.file, "r")) {
                    f.seek(at);
                    int r = f.read(buf, off, n);
                    if (r > 0) return r;
                } catch (IOException e) {
                    if (stop) return -1;
                }
            }
            if (done) return -1;
            if (waited > 30_000) throw new IOException("The live buffer stopped receiving the channel");
            try {
                synchronized (this) { wait(100); }
            } catch (InterruptedException e) {
                throw new InterruptedIOException();
            }
            waited += 100;
        }
    }

    // ---------- writing (the download side) ----------

    private RandomAccessFile out;
    private Chunk cur;
    private long lastMark = 0;

    private void write(byte[] b, int off, int n) throws IOException {
        long now = System.currentTimeMillis();
        if (cur == null || cur.len >= CHUNK_BYTES) {
            if (out != null) out.close();
            Chunk c = new Chunk(written, new File(dir, "ts-" + written + ".ts"), now);
            out = new RandomAccessFile(c.file, "rw");
            synchronized (this) { chunks.add(c); }
            cur = c;
            trim(now);
        }
        out.write(b, off, n);
        synchronized (this) {
            if (now - lastMark >= 250) {
                marks.add(new long[]{now, written});
                lastMark = now;
            }
            cur.len += n;
            written += n;
            if (firstData == 0) firstData = now;
            notifyAll();
        }
    }

    /** Drops the oldest chunks once the buffer is longer than allowed. */
    private synchronized void trim(long now) {
        while (chunks.size() > 2) {
            Chunk first = chunks.get(0);
            long bytes = written - first.start;
            if (now - chunks.get(1).wall < maxMs && bytes <= maxBytes) break;
            chunks.remove(0);
            first.file.delete();
            long keep = chunks.get(0).start;
            while (!marks.isEmpty() && marks.get(0)[1] < keep) marks.remove(0);
        }
    }

    private void run() {
        try {
            boolean hls = "hls".equals(type) || url.toLowerCase(Locale.ROOT).contains(".m3u8");
            if (hls || copyRaw()) copyHls();
        } catch (Exception e) {
            if (!stop) error = e.getMessage() == null ? e.toString() : e.getMessage();
        } finally {
            try { if (out != null) out.close(); } catch (IOException ignored) { }
            done = true;
            synchronized (this) { notifyAll(); }
        }
    }

    /** Copies a plain stream. Returns true if the address turned out to be an HLS playlist. */
    private boolean copyRaw() throws IOException {
        byte[] buf = new byte[64 * 1024];
        int fails = 0;
        boolean first = true;
        while (!stop) {
            HttpURLConnection c = null;
            try {
                c = open(url);
                String ct = c.getContentType() == null ? "" : c.getContentType().toLowerCase(Locale.ROOT);
                if (ct.contains("mpegurl")) return true;
                try (InputStream in = c.getInputStream()) {
                    int n;
                    while (!stop && (n = in.read(buf)) > 0) {
                        if (first) {
                            first = false;
                            if (n >= 7 && new String(buf, 0, 7, "UTF-8").equals("#EXTM3U")) return true;
                        }
                        write(buf, 0, n);
                        fails = 0;
                    }
                }
            } catch (IOException e) {
                if (stop) break;
                error = e.getMessage() == null ? e.toString() : e.getMessage();
                fails++;
                if (written == 0 && fails >= 3) throw e;
            } finally {
                if (c != null) c.disconnect();
            }
            if (!stop) pause(Math.min(5000, 800L * Math.max(1, fails)));
        }
        return false;
    }

    private void copyHls() throws IOException {
        String pl = url;
        long last = -1;
        int fails = 0;
        while (!stop) {
            String text;
            try {
                text = fetchText(pl);
                fails = 0;
            } catch (IOException e) {
                if (stop) break;
                if (++fails >= 4 && written == 0) throw e;
                pause(2000);
                continue;
            }
            if (text.contains("#EXT-X-STREAM-INF")) {
                pl = resolve(pl, bestVariant(text));
                continue;
            }
            if (text.contains("#EXT-X-MAP:")) throw new IOException("This channel's format can't be buffered");
            long seq = 0;
            double target = 6;
            List<String> segs = new ArrayList<>();
            boolean nextIsSeg = false;
            for (String raw : text.split("\n")) {
                String l = raw.trim();
                if (l.isEmpty()) continue;
                if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) seq = (long) num(l.substring(22));
                else if (l.startsWith("#EXT-X-TARGETDURATION:")) target = num(l.substring(22));
                else if (l.startsWith("#EXT-X-KEY:") && !l.contains("METHOD=NONE")) throw new IOException("This channel is encrypted and can't be buffered");
                else if (l.startsWith("#EXTINF")) nextIsSeg = true;
                else if (!l.startsWith("#") && nextIsSeg) {
                    segs.add(l);
                    nextIsSeg = false;
                }
            }
            // start near the live edge, like a player would, rather than at the oldest segment
            int from = last < 0 ? Math.max(0, segs.size() - 3) : 0;
            for (int i = from; i < segs.size() && !stop; i++) {
                long s = seq + i;
                if (s <= last) continue;
                try {
                    HttpURLConnection c = open(resolve(pl, segs.get(i)));
                    try (InputStream in = c.getInputStream()) {
                        byte[] buf = new byte[64 * 1024];
                        int r;
                        while (!stop && (r = in.read(buf)) > 0) write(buf, 0, r);
                    } finally {
                        c.disconnect();
                    }
                } catch (IOException e) {
                    if (stop) break;
                    error = e.getMessage() == null ? e.toString() : e.getMessage();
                }
                last = s;
            }
            if (text.contains("#EXT-X-ENDLIST")) break;
            pause((long) Math.max(1000, target * 500));
        }
    }

    private String fetchText(String u) throws IOException {
        HttpURLConnection c = open(u);
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[16 * 1024];
            int r;
            while ((r = in.read(buf)) > 0) b.write(buf, 0, r);
            return b.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    private HttpURLConnection open(String u) throws IOException {
        String cur = u;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(false);
            if (!ua.isEmpty()) c.setRequestProperty("User-Agent", ua);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirect without an address");
                cur = resolve(cur, loc);
                continue;
            }
            if (code >= 400) {
                c.disconnect();
                throw new IOException("The server answered " + code);
            }
            return c;
        }
        throw new IOException("Too many redirects");
    }

    private static String bestVariant(String text) {
        String best = null;
        double bw = -1;
        String[] lines = text.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i].trim();
            if (!l.startsWith("#EXT-X-STREAM-INF")) continue;
            double b = 0;
            int k = l.indexOf("BANDWIDTH=");
            if (k >= 0) {
                int e = l.indexOf(',', k);
                b = num(e < 0 ? l.substring(k + 10) : l.substring(k + 10, e));
            }
            for (int j = i + 1; j < lines.length; j++) {
                String n = lines[j].trim();
                if (n.isEmpty() || n.startsWith("#")) continue;
                if (b > bw) { bw = b; best = n; }
                break;
            }
        }
        return best == null ? "" : best;
    }

    private static double num(String s) {
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return 0; }
    }

    private static String resolve(String base, String rel) {
        try { return new URL(new URL(base), rel).toString(); } catch (Exception e) { return rel; }
    }

    private void pause(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }
}
