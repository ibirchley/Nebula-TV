package tv.nebula.app;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/** Notes crashes in a small file, so the in-app error log can show them after the app restarts. */
final class CrashNote implements Thread.UncaughtExceptionHandler {
    private static final String FILE = "crashes.json";
    private final Context ctx;
    private final Thread.UncaughtExceptionHandler next;

    CrashNote(Context ctx, Thread.UncaughtExceptionHandler next) {
        this.ctx = ctx;
        this.next = next;
    }

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        try {
            save(ctx, "The app crashed (" + t.getName() + ")", e);
        } catch (Throwable ignored) {
        }
        if (next != null) next.uncaughtException(t, e);
    }

    static synchronized void save(Context ctx, String title, Throwable e) {
        try {
            File f = new File(ctx.getFilesDir(), FILE);
            JSONArray a = f.exists() ? new JSONArray(readText(f)) : new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("msg", title);
            if (e != null) {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String trace = sw.toString();
                o.put("detail", trace.length() > 6000 ? trace.substring(0, 6000) : trace);
            }
            a.put(o);
            while (a.length() > 10) a.remove(0);
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(a.toString().getBytes("UTF-8"));
            }
        } catch (Throwable ignored) {
        }
    }

    // java.nio.file needs Android 8; older Fire TV sticks run Android 5
    private static String readText(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) b.write(buf, 0, r);
            return b.toString("UTF-8");
        }
    }

    static synchronized String take(Context ctx) {
        try {
            File f = new File(ctx.getFilesDir(), FILE);
            if (!f.exists()) return "";
            String s = readText(f);
            f.delete();
            return s;
        } catch (Throwable e) {
            return "";
        }
    }
}
