package tv.nebula.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/**
 * Opens Nebula TV when the box starts up, if that's switched on in Settings.
 * "wake" also keeps a small service running that opens it each time the TV wakes from standby.
 */
public class AutoStart extends BroadcastReceiver {
    static final String PREFS = "autostart";

    static String mode(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("mode", "off");
    }

    /** Android 10 and later only let an app open itself if it may "display over other apps". */
    static boolean allowed(Context c) {
        if (Build.VERSION.SDK_INT < 29) return true;
        try { return android.provider.Settings.canDrawOverlays(c); } catch (Throwable t) { return false; }
    }

    static void open(Context c) {
        try {
            Intent i = new Intent(c, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            i.putExtra("autostart", true);
            c.startActivity(i);
        } catch (Throwable ignored) { }
    }

    static void applyMode(Context c) {
        String m = mode(c);
        Intent svc = new Intent(c, WakeService.class);
        try {
            if ("wake".equals(m)) {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(svc); else c.startService(svc);
            } else {
                c.stopService(svc);
            }
        } catch (Throwable ignored) { }
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String m = mode(ctx);
        if ("off".equals(m)) return;
        String a = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || "android.intent.action.QUICKBOOT_POWERON".equals(a)
                || "android.intent.action.LOCKED_BOOT_COMPLETED".equals(a)) {
            applyMode(ctx);
            if (allowed(ctx)) open(ctx);
        } else if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            applyMode(ctx);   // keep the wake service running after an update, but don't pop the app up
        }
    }
}
