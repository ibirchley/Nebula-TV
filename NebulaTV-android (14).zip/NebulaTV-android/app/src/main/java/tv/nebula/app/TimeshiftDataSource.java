package tv.nebula.app;

import android.net.Uri;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.datasource.BaseDataSource;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;

import java.io.IOException;

/**
 * Lets the player read the live buffer as an endless file. The address is timeshift://buf/OFFSET,
 * where OFFSET is the byte to start from; reads wait for more of the channel when they catch up.
 */
final class TimeshiftDataSource extends BaseDataSource {
    static final class Factory implements DataSource.Factory {
        private final Timeshift ts;
        Factory(Timeshift ts) { this.ts = ts; }
        @Override
        public DataSource createDataSource() { return new TimeshiftDataSource(ts); }
    }

    private final Timeshift ts;
    @Nullable private Uri uri;
    @Nullable private DataSpec spec;
    private long pos;
    private boolean opened;

    TimeshiftDataSource(Timeshift ts) {
        super(false);
        this.ts = ts;
    }

    static Uri uriFor(long offset) {
        return Uri.parse("timeshift://buf/" + offset);
    }

    @Override
    public long open(DataSpec dataSpec) throws IOException {
        spec = dataSpec;
        uri = dataSpec.uri;
        transferInitializing(dataSpec);
        long base = 0;
        try { base = Long.parseLong(dataSpec.uri.getLastPathSegment()); } catch (Exception ignored) { }
        pos = Math.max(base + dataSpec.position, ts.earliestOffset());
        opened = true;
        transferStarted(dataSpec);
        return C.LENGTH_UNSET;
    }

    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
        if (length == 0) return 0;
        int n = ts.read(pos, buffer, offset, length);
        if (n == -2) {                     // fell out of the buffer window: carry on from the oldest part kept
            pos = ts.earliestOffset();
            n = ts.read(pos, buffer, offset, length);
        }
        if (n < 0) return C.RESULT_END_OF_INPUT;
        pos += n;
        bytesTransferred(n);
        return n;
    }

    @Nullable
    @Override
    public Uri getUri() { return uri; }

    @Override
    public void close() {
        uri = null;
        if (opened) {
            opened = false;
            transferEnded();
        }
    }
}
