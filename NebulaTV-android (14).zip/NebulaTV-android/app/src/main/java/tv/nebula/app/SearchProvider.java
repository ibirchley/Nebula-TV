package tv.nebula.app;

import android.app.SearchManager;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.provider.BaseColumns;

import org.json.JSONArray;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Answers the TV's own search (and "Hey Google, find ...") with channels, films, series and
 * programmes from the user's playlist. The web page writes the list to search_index.json.
 */
public class SearchProvider extends ContentProvider {
    // Each entry: [title, subtitle, image, link, kind, year, start, end]
    private JSONArray index;
    private long loadedAt = -1L;

    static File indexFile(android.content.Context c) { return new File(c.getFilesDir(), "search_index.json"); }

    @Override public boolean onCreate() { return true; }

    private synchronized JSONArray load() {
        try {
            File f = indexFile(getContext());
            if (!f.exists()) return null;
            if (index != null && f.lastModified() == loadedAt) return index;
            byte[] b = new byte[(int) f.length()];
            FileInputStream in = new FileInputStream(f);
            try {
                int off = 0, n;
                while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            } finally { in.close(); }
            index = new JSONArray(new String(b, "UTF-8"));
            loadedAt = f.lastModified();
        } catch (Throwable t) { index = null; }
        return index;
    }

    static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.UK).replaceAll("[^a-z0-9]+", " ").trim();
    }

    /** Higher is better; 0 means no match. */
    static int score(String title, String q) {
        String t = norm(title);
        if (q.isEmpty() || t.isEmpty()) return 0;
        if (t.equals(q)) return 100;
        if (t.startsWith(q)) return 80;
        if ((" " + t).contains(" " + q)) return 60;
        if (q.length() >= 3 && t.contains(q)) return 30;
        return 0;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        String q = selectionArgs != null && selectionArgs.length > 0 ? selectionArgs[0] : uri.getLastPathSegment();
        if (q == null || SearchManager.SUGGEST_URI_PATH_QUERY.equals(q)) q = "";
        q = norm(q);
        int limit = 20;
        try { String l = uri.getQueryParameter("limit"); if (l != null) limit = Math.max(1, Math.min(50, Integer.parseInt(l))); } catch (Exception ignored) { }
        String[] cols = {BaseColumns._ID, SearchManager.SUGGEST_COLUMN_TEXT_1, SearchManager.SUGGEST_COLUMN_TEXT_2,
                SearchManager.SUGGEST_COLUMN_RESULT_CARD_IMAGE, SearchManager.SUGGEST_COLUMN_INTENT_DATA,
                SearchManager.SUGGEST_COLUMN_CONTENT_TYPE, SearchManager.SUGGEST_COLUMN_IS_LIVE,
                SearchManager.SUGGEST_COLUMN_PRODUCTION_YEAR};
        MatrixCursor out = new MatrixCursor(cols);
        JSONArray idx = load();
        if (idx == null || q.length() < 2) return out;
        long now = System.currentTimeMillis();
        ArrayList<int[]> hits = new ArrayList<>();
        for (int i = 0; i < idx.length(); i++) {
            JSONArray e = idx.optJSONArray(i);
            if (e == null) continue;
            long end = e.optLong(7, 0);
            if (end > 0 && end < now) continue;
            int s = score(e.optString(0), q);
            if (s == 0) continue;
            String kind = e.optString(4);
            if ("live".equals(kind)) s += 5;
            if ("prog".equals(kind)) { s -= 3; if (e.optLong(6, 0) <= now) s += 4; }
            hits.add(new int[]{s, i});
        }
        java.util.Collections.sort(hits, (a, b) -> a[0] != b[0] ? b[0] - a[0] : a[1] - b[1]);
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        int id = 0;
        for (int[] h : hits) {
            if (id >= limit) break;
            JSONArray e = idx.optJSONArray(h[1]);
            String kind = e.optString(4);
            if (!seen.add(e.optString(0) + "|" + e.optString(3))) continue;
            boolean live = "live".equals(kind) || ("prog".equals(kind) && e.optLong(6, 0) <= now);
            String type = "movie".equals(kind) ? "video/movie" : "series".equals(kind) ? "video/series" : "video/channel";
            int year = e.optInt(5, 0);
            out.addRow(new Object[]{++id, e.optString(0), e.optString(1), e.optString(2), e.optString(3), type,
                    live ? 1 : 0, year > 0 ? year : null});
        }
        return out;
    }

    @Override public String getType(Uri uri) { return SearchManager.SUGGEST_MIME_TYPE; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
