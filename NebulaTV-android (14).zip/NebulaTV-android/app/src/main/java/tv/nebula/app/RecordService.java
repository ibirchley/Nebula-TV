package tv.nebula.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Records live channels to the box's storage (or a USB stick / SD card), now or on a schedule.
 * Runs as a foreground service so recordings carry on when the app is closed or the TV is on another app.
 * Plain MPEG-TS streams are copied byte for byte; HLS (.m3u8) streams are recorded segment by segment.
 */
public class RecordService extends Service {

    static final String ACTION_START = "tv.nebula.app.REC_START";
    static final String ACTION_STOP = "tv.nebula.app.REC_STOP";
    private static final String CHANNEL = "rec";
    private static final int NOTE_ID = 4711;

    /** Recordings currently running in this process. */
    static final Set<String> active = Collections.synchronizedSet(new HashSet<String>());
    private final ConcurrentHashMap<String, Recorder> running = new ConcurrentHashMap<>();
    /** Films and episodes download one at a time, so they never use up the provider's connections. */
    private final java.util.LinkedList<String> dlQueue = new java.util.LinkedList<>();

    private boolean downloadRunning() {
        for (Recorder r : running.values()) if (r.vod) return true;
        return false;
    }
    private PowerManager.WakeLock wake;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground();
        String action = intent == null ? null : intent.getAction();
        String id = intent == null ? null : intent.getStringExtra("id");
        if (ACTION_STOP.equals(action) && id != null) {
            Recorder r = running.get(id);
            if (r != null) r.stopNow();
        } else if (ACTION_STOP.equals(action) && id != null && dlQueue.remove(id)) {
            Store.update(this, id, "status", "cancelled");
        } else if (id != null && !running.containsKey(id)) {
            JSONObject it = Store.get(this, id);
            if (it != null && it.optLong("end") > System.currentTimeMillis()
                    && !"cancelled".equals(it.optString("status")) && !"done".equals(it.optString("status"))) {
                if (it.optBoolean("vod") && downloadRunning()) {
                    if (!dlQueue.contains(id)) dlQueue.add(id);
                    Store.update(this, id, "status", "queued");
                    active.add(id);
                } else {
                    begin(it);
                }
            }
        }
        if (running.isEmpty() && dlQueue.isEmpty()) finishIfIdle();
        else updateNote();
        return START_NOT_STICKY;
    }

    private void begin(JSONObject it) {
        String id = it.optString("id");
        Recorder r = new Recorder(this, it);
        running.put(id, r);
        active.add(id);
        new Thread(r, "rec-" + id).start();
    }

    private void goForeground() {
        Notification n = buildNote("Getting ready to record");
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(NOTE_ID, n);
        } catch (Exception ignored) {
        }
        if (wake == null) {
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nebula:rec");
                wake.setReferenceCounted(false);
                wake.acquire(12 * 3600 * 1000L);
            } catch (Exception ignored) {
            }
        }
    }

    private Notification buildNote(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Recordings", NotificationManager.IMPORTANCE_LOW));
            }
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        int pf = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Nebula TV")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(PendingIntent.getActivity(this, 0, open, pf));
        return b.build();
    }

    private void updateNote() {
        StringBuilder t = new StringBuilder();
        for (Recorder r : running.values()) {
            if (t.length() > 0) t.append(", ");
            t.append(r.title);
        }
        boolean dl = false;
        for (Recorder r : running.values()) dl |= r.vod;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        try {
            if (nm != null) nm.notify(NOTE_ID, buildNote((dl ? "Downloading " : "Recording ") + t + (dlQueue.isEmpty() ? "" : " (+" + dlQueue.size() + " waiting)")));
        } catch (Exception ignored) {
        }
    }

    void finished(Recorder r) {
        running.remove(r.id);
        active.remove(r.id);
        if (r.vod) {
            while (!dlQueue.isEmpty()) {
                String next = dlQueue.removeFirst();
                JSONObject it = Store.get(this, next);
                if (it != null && "queued".equals(it.optString("status"))) {
                    begin(it);
                    break;
                }
                active.remove(next);
            }
        }
        if (running.isEmpty()) finishIfIdle();
        else updateNote();
    }

    private void finishIfIdle() {
        if (!running.isEmpty() || !dlQueue.isEmpty()) return;
        try {
            if (wake != null && wake.isHeld()) wake.release();
        } catch (Exception ignored) {
        }
        wake = null;
        try {
            stopForeground(true);
        } catch (Exception ignored) {
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        for (Recorder r : running.values()) r.stopNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // One recording.
    // ------------------------------------------------------------------
    static class Recorder implements Runnable {
        final RecordService svc;
        final String id, url, ua, type, title, ext;
        final long end;
        final boolean vod;
        private long total = 0;
        private volatile boolean stop = false;
        private File file;
        private long size = 0, lastSave = 0;
        private String lastErr = "";

        Recorder(RecordService svc, JSONObject it) {
            this.svc = svc;
            id = it.optString("id");
            url = it.optString("url");
            ua = it.optString("ua");
            type = it.optString("type");
            title = it.optString("title", "Recording");
            end = it.optLong("end");
            vod = it.optBoolean("vod");
            String e = it.optString("ext", "ts").replaceAll("[^A-Za-z0-9]", "");
            ext = e.isEmpty() ? "ts" : e;
            String f = it.optString("file");
            if (!f.isEmpty()) file = new File(f);
        }

        void stopNow() {
            stop = true;
        }

        private boolean going() {
            return !stop && System.currentTimeMillis() < end;
        }

        @Override
        public void run() {
            try {
                if (file == null) {
                    File dir = recDir(svc);
                    String stamp = new SimpleDateFormat("yyyyMMdd-HHmm", Locale.UK).format(new Date());
                    String safe = title.replaceAll("[^A-Za-z0-9 _-]+", "").trim().replace(' ', '_');
                    if (safe.isEmpty()) safe = "Recording";
                    if (safe.length() > 60) safe = safe.substring(0, 60);
                    file = new File(dir, safe + "_" + stamp + "." + ext);
                }
                size = file.exists() ? file.length() : 0;
                Store.update(svc, id, "status", "recording", "file", file.getAbsolutePath(), "err", "");
                boolean hls = "hls".equals(type) || url.toLowerCase(Locale.ROOT).contains(".m3u8");
                try (OutputStream out = new FileOutputStream(file, true)) {
                    if (hls || recordRaw(out)) recordHls(out);
                }
            } catch (Exception e) {
                lastErr = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            String status = size > 0 && (!vod || total <= 0 || size >= total - 1024 || stop) ? "done" : "failed";
            if (vod && stop && size < total) status = "cancelled";
            Store.update(svc, id, "status", status, "size", size, "stopped", System.currentTimeMillis(), "err", size > 0 ? "" : (lastErr.isEmpty() ? "No data received" : lastErr));
            svc.finished(this);
        }

        private void progress() {
            long now = System.currentTimeMillis();
            if (now - lastSave > 5000) {
                lastSave = now;
                Store.update(svc, id, "size", size, "total", total);
            }
        }

        /** Copies a plain stream. Returns true if the address turned out to be an HLS playlist instead. */
        private boolean recordRaw(OutputStream out) throws IOException {
            byte[] buf = new byte[64 * 1024];
            int fails = 0;
            boolean first = true;
            while (going()) {
                HttpURLConnection c = null;
                try {
                    c = open(url, vod && size > 0 ? size : 0);
                    if (vod) {
                        long len = -1;
                        try { len = Long.parseLong(c.getHeaderField("Content-Length")); } catch (Exception ignored) { }
                        if (c.getResponseCode() == 206 && len > 0) total = size + len;
                        else if (len > 0) {
                            if (size > 0) {  // the server ignored our resume request: start the file again
                                out.flush();
                                if (out instanceof FileOutputStream) ((FileOutputStream) out).getChannel().truncate(0);
                                size = 0;
                            }
                            total = len;
                        }
                    }
                    String ct = c.getContentType() == null ? "" : c.getContentType().toLowerCase(Locale.ROOT);
                    if (ct.contains("mpegurl")) return true;
                    try (InputStream in = c.getInputStream()) {
                        int n;
                        while (going() && (n = in.read(buf)) > 0) {
                            if (first) {
                                first = false;
                                if (n >= 7 && new String(buf, 0, 7, "UTF-8").equals("#EXTM3U")) return true;
                            }
                            out.write(buf, 0, n);
                            size += n;
                            fails = 0;
                            progress();
                        }
                    }
                    if (vod && (total <= 0 || size >= total)) return false;   // the whole file has arrived
                } catch (IOException e) {
                    lastErr = e.getMessage() == null ? e.toString() : e.getMessage();
                    fails++;
                    if (vod && fails > 12) throw e;
                } finally {
                    if (c != null) c.disconnect();
                }
                if (going()) sleep(Math.min(10000, 1500L * Math.max(1, fails)));
            }
            return false;
        }

        private void recordHls(OutputStream out) throws IOException {
            String pl = url;
            long last = -1;
            boolean wroteMap = false;
            while (going()) {
                String text;
                try {
                    text = fetchText(pl);
                } catch (IOException e) {
                    lastErr = e.getMessage() == null ? e.toString() : e.getMessage();
                    sleep(3000);
                    continue;
                }
                if (text.contains("#EXT-X-STREAM-INF")) {
                    pl = resolve(pl, bestVariant(text));
                    continue;
                }
                long seq = 0;
                double target = 6;
                boolean ended = text.contains("#EXT-X-ENDLIST");
                List<String> segs = new ArrayList<>();
                String map = null;
                boolean nextIsSeg = false;
                for (String raw : text.split("\n")) {
                    String l = raw.trim();
                    if (l.isEmpty()) continue;
                    if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) seq = parseLong(l.substring(22));
                    else if (l.startsWith("#EXT-X-TARGETDURATION:")) target = parseLong(l.substring(22));
                    else if (l.startsWith("#EXT-X-KEY:") && !l.contains("METHOD=NONE")) throw new IOException("This channel is encrypted and can't be recorded");
                    else if (l.startsWith("#EXT-X-MAP:")) map = attr(l, "URI");
                    else if (l.startsWith("#EXTINF")) nextIsSeg = true;
                    else if (!l.startsWith("#") && nextIsSeg) {
                        segs.add(l);
                        nextIsSeg = false;
                    }
                }
                if (map != null && !wroteMap) {
                    size += download(resolve(pl, map), out);
                    wroteMap = true;
                }
                for (int i = 0; i < segs.size() && going(); i++) {
                    long s = seq + i;
                    if (s <= last) continue;
                    try {
                        size += download(resolve(pl, segs.get(i)), out);
                    } catch (IOException e) {
                        lastErr = e.getMessage() == null ? e.toString() : e.getMessage();
                    }
                    last = s;
                    progress();
                }
                if (ended) break;
                sleep((long) Math.max(1000, target * 500));
            }
        }

        private long download(String u, OutputStream out) throws IOException {
            HttpURLConnection c = open(u);
            long n = 0;
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[64 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) {
                    out.write(buf, 0, r);
                    n += r;
                }
            } finally {
                c.disconnect();
            }
            return n;
        }

        private String fetchText(String u) throws IOException {
            HttpURLConnection c = open(u);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[16 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) b.write(buf, 0, r);
                return b.toString("UTF-8");
            } finally {
                c.disconnect();
            }
        }

        private HttpURLConnection open(String u) throws IOException {
            return open(u, 0);
        }

        private HttpURLConnection open(String u, long from) throws IOException {
            String cur = u;
            for (int hop = 0; hop < 6; hop++) {
                HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setInstanceFollowRedirects(false);
                if (ua != null && !ua.isEmpty()) c.setRequestProperty("User-Agent", ua);
                if (from > 0) c.setRequestProperty("Range", "bytes=" + from + "-");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null) throw new IOException("Redirect without an address");
                    cur = resolve(cur, loc);
                    continue;
                }
                if (code >= 400) {
                    c.disconnect();
                    throw new IOException("The server answered " + code);
                }
                return c;
            }
            throw new IOException("Too many redirects");
        }

        private static String bestVariant(String text) {
            String best = null;
            long bw = -1;
            String[] lines = text.split("\n");
            for (int i = 0; i < lines.length; i++) {
                String l = lines[i].trim();
                if (!l.startsWith("#EXT-X-STREAM-INF")) continue;
                long b = parseLong(attr(l, "BANDWIDTH"));
                for (int j = i + 1; j < lines.length; j++) {
                    String n = lines[j].trim();
                    if (n.isEmpty() || n.startsWith("#")) continue;
                    if (b > bw) {
                        bw = b;
                        best = n;
                    }
                    break;
                }
            }
            return best == null ? "" : best;
        }

        private static String attr(String line, String key) {
            int i = line.indexOf(key + "=");
            if (i < 0) return "";
            int s = i + key.length() + 1;
            if (s < line.length() && line.charAt(s) == '"') {
                int e = line.indexOf('"', s + 1);
                return e < 0 ? line.substring(s + 1) : line.substring(s + 1, e);
            }
            int e = line.indexOf(',', s);
            return e < 0 ? line.substring(s) : line.substring(s, e);
        }

        private static long parseLong(String s) {
            try {
                return (long) Double.parseDouble(s.trim());
            } catch (Exception e) {
                return 0;
            }
        }

        private static String resolve(String base, String rel) {
            try {
                return new URL(new URL(base), rel).toString();
            } catch (Exception e) {
                return rel;
            }
        }

        private static void sleep(long ms) {
            try {
                Thread.sleep(ms);
            } catch (InterruptedException ignored) {
            }
        }
    }

    // ------------------------------------------------------------------
    // Where recordings go, and the list of recordings (kept in app preferences).
    // ------------------------------------------------------------------
    static File[] storageDirs(Context ctx) {
        File[] all = ctx.getExternalFilesDirs(null);
        List<File> ok = new ArrayList<>();
        if (all != null) for (File f : all) if (f != null) ok.add(f);
        if (ok.isEmpty()) ok.add(ctx.getFilesDir());
        return ok.toArray(new File[0]);
    }

    static File recDir(Context ctx) {
        File[] dirs = storageDirs(ctx);
        int i = ctx.getSharedPreferences("nebula_rec", Context.MODE_PRIVATE).getInt("dir", 0);
        File base = dirs[Math.max(0, Math.min(i, dirs.length - 1))];
        File d = new File(base, "Recordings");
        if (!d.exists() && !d.mkdirs()) d = new File(ctx.getFilesDir(), "Recordings");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static JSONArray storageJson(Context ctx) {
        JSONArray a = new JSONArray();
        File[] dirs = storageDirs(ctx);
        int sel = ctx.getSharedPreferences("nebula_rec", Context.MODE_PRIVATE).getInt("dir", 0);
        for (int i = 0; i < dirs.length; i++) {
            try {
                JSONObject o = new JSONObject();
                boolean removable = false;
                try {
                    removable = Environment.isExternalStorageRemovable(dirs[i]);
                } catch (Exception ignored) {
                }
                o.put("i", i);
                o.put("path", dirs[i].getAbsolutePath());
                o.put("free", dirs[i].getUsableSpace());
                o.put("total", dirs[i].getTotalSpace());
                o.put("removable", removable);
                o.put("on", i == sel);
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        return a;
    }

    static final class Store {
        private static SharedPreferences prefs(Context ctx) {
            return ctx.getSharedPreferences("nebula_rec", Context.MODE_PRIVATE);
        }

        static synchronized JSONArray all(Context ctx) {
            try {
                return new JSONArray(prefs(ctx).getString("list", "[]"));
            } catch (Exception e) {
                return new JSONArray();
            }
        }

        static synchronized void save(Context ctx, JSONArray a) {
            prefs(ctx).edit().putString("list", a.toString()).apply();
        }

        static synchronized JSONObject get(Context ctx, String id) {
            JSONArray a = all(ctx);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && id.equals(o.optString("id"))) return o;
            }
            return null;
        }

        static synchronized void put(Context ctx, JSONObject item) {
            JSONArray a = all(ctx), b = new JSONArray();
            String id = item.optString("id");
            boolean done = false;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                if (id.equals(o.optString("id"))) {
                    b.put(item);
                    done = true;
                } else b.put(o);
            }
            if (!done) b.put(item);
            save(ctx, b);
        }

        static synchronized void remove(Context ctx, String id) {
            JSONArray a = all(ctx), b = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && !id.equals(o.optString("id"))) b.put(o);
            }
            save(ctx, b);
        }

        static synchronized void update(Context ctx, String id, Object... kv) {
            JSONObject o = get(ctx, id);
            if (o == null) return;
            try {
                for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
            } catch (Exception ignored) {
            }
            put(ctx, o);
        }
    }

    // ------------------------------------------------------------------
    // Alarms: wake the box at the right time to start each scheduled recording.
    // ------------------------------------------------------------------
    private static PendingIntent alarmIntent(Context ctx, String id) {
        Intent i = new Intent(ctx, RecAlarm.class).setAction("tv.nebula.app.REC_ALARM").putExtra("id", id);
        int pf = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(ctx, id.hashCode(), i, pf);
    }

    static void startNow(Context ctx, String id) {
        Intent i = new Intent(ctx, RecordService.class).setAction(ACTION_START).putExtra("id", id);
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
        } catch (Exception e) {
            Store.update(ctx, id, "status", "failed", "err", "Android would not let the recording start: " + e.getMessage());
        }
    }

    static void stop(Context ctx, String id) {
        if (active.contains(id)) {
            Intent i = new Intent(ctx, RecordService.class).setAction(ACTION_STOP).putExtra("id", id);
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
                else ctx.startService(i);
            } catch (Exception ignored) {
            }
        }
        cancelAlarm(ctx, id);
    }

    static void cancelAlarm(Context ctx, String id) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(alarmIntent(ctx, id));
        } catch (Exception ignored) {
        }
    }

    static void schedule(Context ctx, JSONObject it) {
        String id = it.optString("id");
        long start = it.optLong("start"), end = it.optLong("end"), now = System.currentTimeMillis();
        if (end <= now) {
            Store.update(ctx, id, "status", "missed");
            return;
        }
        if (start <= now + 3000) {
            startNow(ctx, id);
            return;
        }
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            PendingIntent pi = alarmIntent(ctx, id);
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (Build.VERSION.SDK_INT >= 23) {
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, start, pi);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, start, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, start, pi);
            }
        } catch (Exception e) {
            Store.update(ctx, id, "err", "Could not set the timer: " + e.getMessage());
        }
    }

    /** After a restart, an update or opening the app: put every pending recording back on its timer. */
    static void rescheduleAll(Context ctx) {
        JSONArray a = Store.all(ctx);
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String st = o.optString("status"), id = o.optString("id");
            if ("scheduled".equals(st)) schedule(ctx, o);
            else if (("recording".equals(st) || "queued".equals(st)) && !active.contains(id)) {
                if (o.optLong("end") > now) startNow(ctx, id);
                else {
                    File f = new File(o.optString("file"));
                    Store.update(ctx, id, "status", f.exists() && f.length() > 0 ? "done" : "failed", "size", f.exists() ? f.length() : 0);
                }
            }
        }
    }
}
