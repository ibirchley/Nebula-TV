package tv.nebula.app;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/**
 * Lets Nebula TV put the box to sleep and open the system power menu (Sleep, Restart, Power off).
 * Android only allows this through an accessibility service the user switches on themselves.
 * It reads nothing on screen.
 */
public class PowerAccess extends AccessibilityService {
    static volatile PowerAccess instance;

    @Override protected void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }
    @Override public boolean onUnbind(android.content.Intent intent) { instance = null; return super.onUnbind(intent); }

    static boolean act(int action) {
        PowerAccess p = instance;
        if (p == null) return false;
        try { return p.performGlobalAction(action); } catch (Throwable t) { return false; }
    }
}
