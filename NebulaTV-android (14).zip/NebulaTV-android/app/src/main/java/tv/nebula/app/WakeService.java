package tv.nebula.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;

/** Listens for the TV waking from standby and opens Nebula TV (Settings: "Every time the TV turns on"). */
public class WakeService extends Service {
    private BroadcastReceiver screen;
    private long lastOpen = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel("autostart", "Open when the TV turns on", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            if (nm != null) nm.createNotificationChannel(ch);
            nb = new Notification.Builder(this, "autostart");
        } else {
            nb = new Notification.Builder(this);
        }
        Notification n = nb.setContentTitle("Nebula TV").setContentText("Opens when the TV turns on")
                .setSmallIcon(R.mipmap.ic_launcher).setOngoing(true).build();
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(7, n);
        } catch (Throwable ignored) { }
        screen = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                if (!"wake".equals(AutoStart.mode(c))) { stopSelf(); return; }
                long now = System.currentTimeMillis();
                if (now - lastOpen < 15000) return;   // one opening per wake
                lastOpen = now;
                if (AutoStart.allowed(c)) AutoStart.open(c);
            }
        };
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screen, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(screen, f);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!"wake".equals(AutoStart.mode(this))) { stopSelf(); return START_NOT_STICKY; }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (screen != null) unregisterReceiver(screen); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
