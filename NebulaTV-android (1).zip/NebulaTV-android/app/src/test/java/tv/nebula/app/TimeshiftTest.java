package tv.nebula.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.sun.net.httpserver.HttpServer;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.concurrent.Executors;

/** The live TV buffer, against a little local server pretending to be an IPTV provider. */
public class TimeshiftTest {
    private static HttpServer server;
    private static String base;
    private static final long T0 = System.currentTimeMillis();
    private File dir;
    private Timeshift ts;

    @BeforeClass
    public static void startServer() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        // a live MPEG-TS channel: 188-byte packets at about 200 KB/s, forever
        server.createContext("/live.ts", ex -> {
            ex.getResponseHeaders().add("Content-Type", "video/mp2t");
            ex.sendResponseHeaders(200, 0);
            try (OutputStream o = ex.getResponseBody()) {
                byte[] p = new byte[188 * 100];
                for (int i = 0; i < p.length; i += 188) p[i] = 0x47;
                while (true) { o.write(p); o.flush(); Thread.sleep(94); }
            } catch (Exception ignored) { }
        });
        // HLS with a rolling playlist of 1-second segments
        server.createContext("/hls/index.m3u8", ex -> {
            long n = (System.currentTimeMillis() - T0) / 1000;
            StringBuilder b = new StringBuilder("#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:" + n + "\n");
            for (long i = n; i < n + 4; i++) b.append("#EXTINF:1.0,\nseg").append(i).append(".ts\n");
            byte[] d = b.toString().getBytes("UTF-8");
            ex.getResponseHeaders().add("Content-Type", "application/vnd.apple.mpegurl");
            ex.sendResponseHeaders(200, d.length);
            ex.getResponseBody().write(d);
            ex.close();
        });
        server.createContext("/hls/", ex -> {
            byte[] d = new byte[188 * 500];
            for (int i = 0; i < d.length; i += 188) d[i] = 0x47;
            ex.sendResponseHeaders(200, d.length);
            ex.getResponseBody().write(d);
            ex.close();
        });
        server.createContext("/enc/index.m3u8", ex -> {
            byte[] d = "#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:1.0,\na.ts\n".getBytes("UTF-8");
            ex.sendResponseHeaders(200, d.length);
            ex.getResponseBody().write(d);
            ex.close();
        });
        server.createContext("/redir.ts", ex -> {
            ex.getResponseHeaders().add("Location", "/live.ts");
            ex.sendResponseHeaders(302, -1);
            ex.close();
        });
        server.createContext("/dead.ts", ex -> { ex.sendResponseHeaders(404, -1); ex.close(); });
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();
        base = "http://127.0.0.1:" + server.getAddress().getPort();
    }

    @AfterClass
    public static void stopServer() { server.stop(0); }

    @Before
    public void setUp() throws Exception {
        dir = Files.createTempDirectory("nebula-ts").toFile();
        Timeshift.CHUNK_BYTES = 8L * 1024 * 1024;
        Timeshift.MIN_MS = 60_000L;
        Timeshift.MIN_BYTES = 64L * 1024 * 1024;
    }

    @After
    public void tearDown() {
        if (ts != null) ts.stop();
    }

    @Test
    public void buffersAPlainStreamThroughARedirect() throws Exception {
        ts = new Timeshift(base + "/redir.ts", "TestAgent", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(2500);
        assertTrue("bytes buffered: " + ts.written(), ts.written() > 200_000);
        assertTrue(ts.error(), !ts.failed());
        byte[] buf = new byte[65536];
        int r = ts.read(0, buf, 0, buf.length);
        assertTrue(r > 0);
        assertEquals(0x47, buf[0]);
    }

    @Test
    public void mapsTimesToPositionsAndBack() throws Exception {
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(3000);
        long wall = System.currentTimeMillis() - 1500;
        long off = ts.offsetAt(wall);
        assertTrue("offset " + off + " of " + ts.written(), off > 0 && off < ts.written());
        assertTrue(Math.abs(ts.wallAt(off) - wall) < 700);
    }

    @Test
    public void readingPastTheEdgeWaitsForMore() throws Exception {
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(1500);
        long t = System.currentTimeMillis();
        int r = ts.read(ts.written() + 40_000, new byte[1000], 0, 1000);
        assertTrue(r > 0);
        assertTrue("waited " + (System.currentTimeMillis() - t) + "ms", System.currentTimeMillis() - t >= 100);
    }

    @Test
    public void dropsOldChunksOutsideTheWindow() throws Exception {
        Timeshift.CHUNK_BYTES = 100_000;
        Timeshift.MIN_MS = 1000;
        Timeshift.MIN_BYTES = 1;
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 2000, 10L << 20);
        ts.start();
        Thread.sleep(5000);
        assertTrue(ts.earliestOffset() > 0);
        assertTrue(System.currentTimeMillis() - ts.earliestWall() < 4000);
        assertEquals(-2, ts.read(0, new byte[100], 0, 100));
        File[] left = dir.listFiles();
        assertTrue(left != null && left.length <= 10);
    }

    @Test
    public void keepsWithinTheSpaceAllowance() throws Exception {
        Timeshift.CHUNK_BYTES = 100_000;
        Timeshift.MIN_BYTES = 1;
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 300_000);
        ts.start();
        Thread.sleep(4000);
        assertTrue(ts.written() - ts.earliestOffset() <= 500_000);
    }

    @Test
    public void buffersHls() throws Exception {
        ts = new Timeshift(base + "/hls/index.m3u8", "", "hls", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(3500);
        assertTrue("HLS bytes: " + ts.written(), ts.written() >= 188 * 500 * 3);
        assertEquals("", ts.error());
    }

    @Test
    public void refusesEncryptedHls() throws Exception {
        ts = new Timeshift(base + "/enc/index.m3u8", "", "hls", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(1500);
        assertTrue(ts.failed());
        assertTrue(ts.error(), ts.error().contains("encrypted"));
    }

    @Test
    public void reportsADeadChannel() throws Exception {
        ts = new Timeshift(base + "/dead.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(6000);
        assertTrue(ts.failed());
        assertTrue(ts.error(), ts.error().contains("404"));
    }

    @Test
    public void stopDeletesTheBufferAndEndsReads() throws Exception {
        ts = new Timeshift(base + "/live.ts", "", "ts", dir, 60_000, 64L << 20);
        ts.start();
        Thread.sleep(1500);
        ts.stop();
        File[] left = dir.listFiles();
        assertTrue(left == null || left.length == 0);
        assertEquals(-1, ts.read(0, new byte[10], 0, 10));
    }
}
