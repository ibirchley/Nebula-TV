package tv.nebula.app;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;

/**
 * Nebula TV — a full-screen WebView host for the Nebula TV web app (assets/index.html).
 * The native side adds what a browser can't do: CORS-free downloads of playlists and
 * guides (with an optional custom User-Agent), remote-control keys and the Back button.
 */
public class MainActivity extends Activity {

    private static final int CHUNK = 512 * 1024;

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final ConcurrentHashMap<Integer, String> results = new ConcurrentHashMap<>();
    private volatile String userAgent = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        goImmersive();

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("file:")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public Bitmap getDefaultVideoPoster() {
                // Hides the grey "play" placeholder Android draws before video starts.
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        });
        web.addJavascriptInterface(new Bridge(), "NebulaNative");
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    private void goImmersive() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) {
                web.evaluateJavascript("(window.nebulaBack ? window.nebulaBack() : false)", value -> {
                    if (!"true".equals(value)) finish();
                });
            }
            return true;
        }
        String key = null;
        switch (code) {
            case KeyEvent.KEYCODE_CHANNEL_UP: key = "chup"; break;
            case KeyEvent.KEYCODE_CHANNEL_DOWN: key = "chdown"; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: key = "playpause"; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY: key = "play"; break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: key = "pause"; break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: key = "ff"; break;
            case KeyEvent.KEYCODE_MEDIA_REWIND: key = "rw"; break;
            case KeyEvent.KEYCODE_MENU: key = "menu"; break;
            case KeyEvent.KEYCODE_INFO: key = "info"; break;
            case KeyEvent.KEYCODE_GUIDE: key = "guide"; break;
            default: break;
        }
        if (key != null) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
                web.evaluateJavascript("window.nebulaKey && window.nebulaKey('" + key + "')", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    private String download(String address, String ua) throws Exception {
        String current = address;
        for (int hop = 0; hop < 8; hop++) {
            URL url = new URL(current);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(90000);
            String agent = (ua != null && !ua.isEmpty()) ? ua : (userAgent.isEmpty() ? System.getProperty("http.agent") : userAgent);
            if (agent != null) c.setRequestProperty("User-Agent", agent);
            c.setRequestProperty("Accept-Encoding", "gzip");
            int status = c.getResponseCode();
            if (status >= 300 && status < 400) {
                String location = c.getHeaderField("Location");
                c.disconnect();
                if (location == null) throw new IOException("Redirect without a location");
                current = new URL(url, location).toString();
                continue;
            }
            if (status >= 400) {
                c.disconnect();
                throw new IOException("Server replied HTTP " + status);
            }
            InputStream in = new BufferedInputStream(c.getInputStream(), 65536);
            in.mark(4);
            int b1 = in.read();
            int b2 = in.read();
            in.reset();
            if (b1 == 0x1f && b2 == 0x8b) in = new GZIPInputStream(in, 65536);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            c.disconnect();
            return out.toString("UTF-8");
        }
        throw new IOException("Too many redirects");
    }

    private boolean isTelevision() {
        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        PackageManager pm = getPackageManager();
        return pm.hasSystemFeature("android.software.leanback")
                || pm.hasSystemFeature("amazon.hardware.fire_tv");
    }

    /** Methods callable from JavaScript as window.NebulaNative.* */
    private class Bridge {

        @JavascriptInterface
        public void fetchText(final int id, final String url, final String ua) {
            pool.execute(() -> {
                boolean ok = true;
                String message;
                try {
                    String body = download(url, ua);
                    results.put(id, body);
                    message = String.valueOf(body.length());
                } catch (Exception ex) {
                    ok = false;
                    String m = ex.getMessage();
                    message = (m == null || m.isEmpty()) ? ex.getClass().getSimpleName() : m;
                    if (ex instanceof java.net.UnknownHostException) message = "Couldn't find that server — check the address";
                    if (ex instanceof java.net.SocketTimeoutException) message = "The server took too long to answer";
                }
                final String js = "window.__nebulaFetchDone && window.__nebulaFetchDone(" + id + "," + ok + "," + JSONObject.quote(message) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            });
        }

        /** Returns the next piece of a finished download, starting at character `start`. */
        @JavascriptInterface
        public String takeChunk(int id, int start) {
            String s = results.get(id);
            if (s == null || start >= s.length()) return "";
            int end = Math.min(s.length(), start + CHUNK);
            if (end < s.length() && Character.isHighSurrogate(s.charAt(end - 1))) end--;
            return s.substring(start, end);
        }

        @JavascriptInterface
        public void release(int id) {
            results.remove(id);
        }

        @JavascriptInterface
        public void setUserAgent(final String ua) {
            userAgent = ua == null ? "" : ua.trim();
            runOnUiThread(() -> web.getSettings().setUserAgentString(userAgent.isEmpty() ? null : userAgent));
        }

        @JavascriptInterface
        public boolean isTv() {
            return isTelevision();
        }

        @JavascriptInterface
        public String platform() {
            return "android " + Build.VERSION.RELEASE;
        }
    }
}
