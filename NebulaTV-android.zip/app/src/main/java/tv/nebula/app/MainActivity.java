package tv.nebula.app;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.TextureView;
import android.view.ViewOutlineProvider;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.os.Handler;
import android.os.Looper;
import android.widget.FrameLayout;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;

/**
 * Nebula TV — a full-screen WebView host for the Nebula TV web app (assets/index.html).
 * The native side adds what a browser can't do: CORS-free downloads of playlists and
 * guides (with an optional custom User-Agent), remote-control keys and the Back button.
 */
public class MainActivity extends Activity {

    private static final int CHUNK = 512 * 1024;

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final ConcurrentHashMap<Integer, String> results = new ConcurrentHashMap<>();
    private volatile String userAgent = "";

    // Native (ExoPlayer) video playback, drawn underneath the transparent WebView.
    private PlayerView playerView;
    private ExoPlayer player;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // Small live preview for the TV guide, drawn on top of the WebView.
    private FrameLayout previewBox;
    private AspectRatioFrameLayout previewFrame;
    private TextureView previewTexture;
    private ExoPlayer preview;
    private ExoPlayer fadingOld;

    // Multi-view: several small players, each in its own box over the WebView.
    private FrameLayout root;
    private final java.util.HashMap<Integer, Slot> slots = new java.util.HashMap<>();

    private static class Slot {
        FrameLayout box;
        AspectRatioFrameLayout frame;
        TextureView tex;
        ExoPlayer player;
    }
    private volatile String tracksJson = "[]";
    private volatile long posMs = 0, durMs = 0;
    private boolean currentLive = false;
    private int liveRetries = 0;
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (player == null) return;
            posMs = player.getCurrentPosition();
            long d = player.getDuration();
            durMs = d == C.TIME_UNSET ? 0 : d;
            if (!currentLive) emit("pos", "{\"p\":" + posMs + ",\"d\":" + durMs + "}");
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        goImmersive();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setShutterBackgroundColor(Color.BLACK);
        playerView.setKeepContentOnPlayerReset(false);
        playerView.setFocusable(false);
        playerView.setVisibility(View.GONE);
        root.addView(playerView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        previewBox = new FrameLayout(this);
        previewBox.setBackgroundColor(Color.BLACK);
        previewBox.setVisibility(View.GONE);
        previewBox.setFocusable(false);
        previewFrame = new AspectRatioFrameLayout(this);
        previewFrame.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        previewTexture = new TextureView(this);
        previewFrame.addView(previewTexture, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        previewBox.addView(previewFrame, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        root.addView(previewBox, new FrameLayout.LayoutParams(1, 1));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("file:")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public Bitmap getDefaultVideoPoster() {
                // Hides the grey "play" placeholder Android draws before video starts.
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        });
        web.addJavascriptInterface(new Bridge(), "NebulaNative");
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    private void goImmersive() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) {
                web.evaluateJavascript("(window.nebulaBack ? window.nebulaBack() : false)", value -> {
                    if (!"true".equals(value)) finish();
                });
            }
            return true;
        }
        String key = null;
        switch (code) {
            case KeyEvent.KEYCODE_CHANNEL_UP: key = "chup"; break;
            case KeyEvent.KEYCODE_CHANNEL_DOWN: key = "chdown"; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: key = "playpause"; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY: key = "play"; break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: key = "pause"; break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: key = "ff"; break;
            case KeyEvent.KEYCODE_MEDIA_REWIND: key = "rw"; break;
            case KeyEvent.KEYCODE_MENU: key = "menu"; break;
            case KeyEvent.KEYCODE_INFO: key = "info"; break;
            case KeyEvent.KEYCODE_GUIDE: key = "guide"; break;
            default: break;
        }
        if (key != null) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
                web.evaluateJavascript("window.nebulaKey && window.nebulaKey('" + key + "')", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
        stopPreview();
        stopAllSlots();
        emit("appStopped", null);
    }

    @Override
    protected void onDestroy() {
        stopPreview();
        stopAllSlots();
        releasePlayer();
        pool.shutdownNow();
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    private String download(String address, String ua) throws Exception {
        String current = address;
        for (int hop = 0; hop < 8; hop++) {
            URL url = new URL(current);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(90000);
            String agent = (ua != null && !ua.isEmpty()) ? ua : (userAgent.isEmpty() ? System.getProperty("http.agent") : userAgent);
            if (agent != null) c.setRequestProperty("User-Agent", agent);
            c.setRequestProperty("Accept-Encoding", "gzip");
            int status = c.getResponseCode();
            if (status >= 300 && status < 400) {
                String location = c.getHeaderField("Location");
                c.disconnect();
                if (location == null) throw new IOException("Redirect without a location");
                current = new URL(url, location).toString();
                continue;
            }
            if (status >= 400) {
                c.disconnect();
                throw new IOException("Server replied HTTP " + status);
            }
            InputStream in = new BufferedInputStream(c.getInputStream(), 65536);
            in.mark(4);
            int b1 = in.read();
            int b2 = in.read();
            in.reset();
            if (b1 == 0x1f && b2 == 0x8b) in = new GZIPInputStream(in, 65536);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            c.disconnect();
            return out.toString("UTF-8");
        }
        throw new IOException("Too many redirects");
    }

    // ---------- native playback ----------

    private void emit(String type, String json) {
        if (web == null) return;
        web.evaluateJavascript("window.__nebulaPlayer && window.__nebulaPlayer('" + type + "'," + (json == null ? "null" : json) + ")", null);
    }

    private void releasePlayer() {
        ui.removeCallbacks(ticker);
        if (player != null) {
            player.release();
            player = null;
        }
        if (playerView != null) {
            playerView.setPlayer(null);
            playerView.setVisibility(View.GONE);
        }
        tracksJson = "[]";
        posMs = 0;
        durMs = 0;
    }

    private void applyFit(String fit) {
        if (playerView == null) return;
        int mode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
        if ("cover".equals(fit)) mode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM;
        else if ("fill".equals(fit)) mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
        playerView.setResizeMode(mode);
    }

    private DefaultMediaSourceFactory buildSources(String ua) {
        String agent = (ua != null && !ua.isEmpty()) ? ua : (userAgent.isEmpty() ? System.getProperty("http.agent") : userAgent);
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000);
        if (agent != null && !agent.isEmpty()) http.setUserAgent(agent);
        DefaultExtractorsFactory extractors = new DefaultExtractorsFactory()
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
                .setConstantBitrateSeekingEnabled(true);
        return new DefaultMediaSourceFactory(http, extractors)
                .setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(8));
    }

    private MediaItem buildItem(String url, String type) {
        MediaItem.Builder item = new MediaItem.Builder().setUri(Uri.parse(url));
        if ("hls".equals(type)) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if ("ts".equals(type)) item.setMimeType(MimeTypes.VIDEO_MP2T);
        return item.build();
    }

    private void placePreview(double x, double y, double w, double h, double scale) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) Math.round(w * scale), (int) Math.round(h * scale));
        lp.leftMargin = (int) Math.round(x * scale);
        lp.topMargin = (int) Math.round(y * scale);
        lp.gravity = Gravity.TOP | Gravity.START;
        previewBox.setLayoutParams(lp);
    }

    private Slot slot(int i) {
        Slot s = slots.get(i);
        if (s == null) {
            s = new Slot();
            s.box = new FrameLayout(this);
            s.box.setBackgroundColor(Color.BLACK);
            s.box.setVisibility(View.GONE);
            s.box.setFocusable(false);
            s.frame = new AspectRatioFrameLayout(this);
            s.frame.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            s.tex = new TextureView(this);
            s.frame.addView(s.tex, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            s.box.addView(s.frame, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            root.addView(s.box, new FrameLayout.LayoutParams(1, 1));
            slots.put(i, s);
        }
        return s;
    }

    private void placeBox(View box, double x, double y, double w, double h, double scale) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) Math.round(w * scale), (int) Math.round(h * scale));
        lp.leftMargin = (int) Math.round(x * scale);
        lp.topMargin = (int) Math.round(y * scale);
        lp.gravity = Gravity.TOP | Gravity.START;
        box.setLayoutParams(lp);
    }

    private void stopSlot(int i) {
        Slot s = slots.get(i);
        if (s == null) return;
        if (s.player != null) {
            s.player.release();
            s.player = null;
        }
        s.box.setVisibility(View.GONE);
    }

    private void stopAllSlots() {
        for (Integer i : new java.util.ArrayList<>(slots.keySet())) stopSlot(i);
    }

    private void startSlot(final int i, String url, double x, double y, double w, double h, double scale, String ua, boolean muted, String type) {
        final Slot s = slot(i);
        if (s.player != null) {
            s.player.release();
            s.player = null;
        }
        placeBox(s.box, x, y, w, h, scale);
        roundCorners(s.box, (float) (9 * scale));
        s.box.setAlpha(0f);
        s.box.setVisibility(View.VISIBLE);
        DefaultLoadControl load = new DefaultLoadControl.Builder().setBufferDurationsMs(10000, 30000, 1500, 3000).build();
        s.player = new ExoPlayer.Builder(this, new DefaultRenderersFactory(this).setEnableDecoderFallback(true))
                .setMediaSourceFactory(buildSources(ua))
                .setLoadControl(load)
                .build();
        s.player.setVideoTextureView(s.tex);
        s.player.setVolume(muted ? 0f : 1f);
        s.player.addListener(new Player.Listener() {
            @Override
            public void onVideoSizeChanged(VideoSize size) {
                if (size.height > 0) s.frame.setAspectRatio(size.width * size.pixelWidthHeightRatio / size.height);
            }

            @Override
            public void onRenderedFirstFrame() {
                s.box.animate().alpha(1f).setDuration(500).start();
            }

            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) emit("multiReady", String.valueOf(i));
                else if (state == Player.STATE_BUFFERING) emit("multiBuffering", String.valueOf(i));
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (s.player != null) {
                    s.player.release();
                    s.player = null;
                }
                emit("multiError", String.valueOf(i));
            }
        });
        s.player.setMediaItem(buildItem(url, type));
        s.player.setPlayWhenReady(true);
        s.player.prepare();
    }

    private void roundCorners(View v, final float radiusPx) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
        v.setClipToOutline(true);
    }

    private void stopPreview() {
        stopPreview(false);
    }

    /** Stops the guide/home preview; with fade, the picture dissolves back to the logo underneath. */
    private void stopPreview(boolean fade) {
        if (previewBox == null) return;
        previewBox.animate().cancel();
        if (preview == null) {
            if (fadingOld == null) previewBox.setVisibility(View.GONE);
            return;
        }
        final ExoPlayer old = preview;
        preview = null;
        if (!fade || previewBox.getVisibility() != View.VISIBLE || previewBox.getAlpha() < 0.05f) {
            old.release();
            previewBox.setVisibility(View.GONE);
            return;
        }
        fadingOld = old;
        previewBox.animate().alpha(0f).setDuration(450).withEndAction(() -> {
            if (fadingOld == old) {
                old.release();
                fadingOld = null;
            }
            if (preview == null) previewBox.setVisibility(View.GONE);
        }).start();
    }

    private void startPreview(String url, double x, double y, double w, double h, double scale, String ua, boolean muted, String type, double radius) {
        previewBox.animate().cancel();
        if (fadingOld != null) {
            fadingOld.release();
            fadingOld = null;
        }
        stopPreview(false);
        placePreview(x, y, w, h, scale);
        roundCorners(previewBox, (float) (radius * scale));
        previewBox.setAlpha(0f);
        previewBox.setVisibility(View.VISIBLE);
        DefaultLoadControl load = new DefaultLoadControl.Builder().setBufferDurationsMs(8000, 20000, 1000, 2000).build();
        preview = new ExoPlayer.Builder(this, new DefaultRenderersFactory(this).setEnableDecoderFallback(true))
                .setMediaSourceFactory(buildSources(ua))
                .setLoadControl(load)
                .build();
        preview.setVideoTextureView(previewTexture);
        preview.setVolume(muted ? 0f : 1f);
        preview.addListener(new Player.Listener() {
            @Override
            public void onVideoSizeChanged(VideoSize size) {
                if (size.height > 0) previewFrame.setAspectRatio(size.width * size.pixelWidthHeightRatio / size.height);
            }

            @Override
            public void onRenderedFirstFrame() {
                previewBox.animate().alpha(1f).setDuration(650).start();
                emit("previewReady", null);
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                stopPreview(true);
                emit("previewError", null);
            }
        });
        preview.setMediaItem(buildItem(url, type));
        preview.setPlayWhenReady(true);
        preview.prepare();
    }

    private void startPlayer(String url, boolean live, String ua, long resumeMs, String fit, String type, int bufferSecs) {
        stopPreview();
        stopAllSlots();
        releasePlayer();
        currentLive = live;
        liveRetries = 0;
        DefaultMediaSourceFactory sources = buildSources(ua);
        int maxBuf = Math.max(50000, bufferSecs * 1000);

        int minBuf = Math.min(maxBuf, Math.max(15000, bufferSecs * 500));
        DefaultLoadControl load = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(minBuf, maxBuf, 2000, 4000)
                .build();
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this).setEnableDecoderFallback(true);
        player = new ExoPlayer.Builder(this, renderers)
                .setMediaSourceFactory(sources)
                .setLoadControl(load)
                .build();
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) emit("buffering", null);
                else if (state == Player.STATE_READY) { liveRetries = 0; emit("playing", null); }
                else if (state == Player.STATE_ENDED) emit("ended", null);
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                emit(isPlaying ? "play" : "pause", null);
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (player == null) return;
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                boolean network = error.errorCode >= 2000 && error.errorCode < 3000;
                if (currentLive && network && liveRetries < 3) {
                    liveRetries++;
                    ui.postDelayed(() -> { if (player != null) player.prepare(); }, 1000L * liveRetries);
                    return;
                }
                String m = error.getErrorCodeName() + (error.getMessage() == null ? "" : ": " + error.getMessage());
                emit("error", JSONObject.quote(m));
            }

            @Override
            public void onTracksChanged(Tracks tracks) {
                tracksJson = buildTracks(tracks);
                emit("tracks", null);
            }
        });
        applyFit(fit);
        playerView.setPlayer(player);
        playerView.setVisibility(View.VISIBLE);
        if (resumeMs > 0) player.setMediaItem(buildItem(url, type), resumeMs);
        else player.setMediaItem(buildItem(url, type));
        player.setPlayWhenReady(true);
        player.prepare();
        ui.post(ticker);
    }

    private String buildTracks(Tracks tracks) {
        JSONArray out = new JSONArray();
        try {
            List<Tracks.Group> groups = tracks.getGroups();
            for (int g = 0; g < groups.size(); g++) {
                Tracks.Group group = groups.get(g);
                int type = group.getType();
                if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_VIDEO && type != C.TRACK_TYPE_TEXT) continue;
                for (int i = 0; i < group.length; i++) {
                    Format f = group.getTrackFormat(i);
                    JSONObject o = new JSONObject();
                    o.put("type", type);
                    o.put("g", g);
                    o.put("i", i);
                    o.put("label", f.label == null ? "" : f.label);
                    o.put("lang", f.language == null ? "" : f.language);
                    o.put("h", f.height);
                    o.put("br", f.bitrate);
                    o.put("ch", f.channelCount);
                    o.put("mime", f.sampleMimeType == null ? "" : f.sampleMimeType);
                    o.put("sel", group.isTrackSelected(i));
                    o.put("sup", group.isTrackSupported(i));
                    out.put(o);
                }
            }
        } catch (Exception ignored) {
        }
        return out.toString();
    }

    private void selectTrack(int type, int g, int i) {
        if (player == null) return;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if (i < 0) {
            b.clearOverridesOfType(type);
            b.setTrackTypeDisabled(type, type == C.TRACK_TYPE_TEXT);
        } else {
            List<Tracks.Group> groups = player.getCurrentTracks().getGroups();
            if (g < 0 || g >= groups.size()) return;
            b.setTrackTypeDisabled(type, false);
            b.setOverrideForType(new TrackSelectionOverride(groups.get(g).getMediaTrackGroup(), i));
        }
        player.setTrackSelectionParameters(b.build());
    }

    private boolean isTelevision() {
        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        PackageManager pm = getPackageManager();
        return pm.hasSystemFeature("android.software.leanback")
                || pm.hasSystemFeature("amazon.hardware.fire_tv");
    }

    /** Methods callable from JavaScript as window.NebulaNative.* */
    private class Bridge {

        @JavascriptInterface
        public void fetchText(final int id, final String url, final String ua) {
            pool.execute(() -> {
                boolean ok = true;
                String message;
                try {
                    String body = download(url, ua);
                    results.put(id, body);
                    message = String.valueOf(body.length());
                } catch (Exception ex) {
                    ok = false;
                    String m = ex.getMessage();
                    message = (m == null || m.isEmpty()) ? ex.getClass().getSimpleName() : m;
                    if (ex instanceof java.net.UnknownHostException) message = "Couldn't find that server — check the address";
                    if (ex instanceof java.net.SocketTimeoutException) message = "The server took too long to answer";
                }
                final String js = "window.__nebulaFetchDone && window.__nebulaFetchDone(" + id + "," + ok + "," + JSONObject.quote(message) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            });
        }

        /** Returns the next piece of a finished download, starting at character `start`. */
        @JavascriptInterface
        public String takeChunk(int id, int start) {
            String s = results.get(id);
            if (s == null || start >= s.length()) return "";
            int end = Math.min(s.length(), start + CHUNK);
            if (end < s.length() && Character.isHighSurrogate(s.charAt(end - 1))) end--;
            return s.substring(start, end);
        }

        @JavascriptInterface
        public void release(int id) {
            results.remove(id);
        }

        @JavascriptInterface
        public void setUserAgent(final String ua) {
            userAgent = ua == null ? "" : ua.trim();
            runOnUiThread(() -> web.getSettings().setUserAgentString(userAgent.isEmpty() ? null : userAgent));
        }

        @JavascriptInterface
        public void nativePlay(final String url, final boolean live, final String ua, final double resumeMs, final String fit, final String type, final int bufferSecs) {
            runOnUiThread(() -> startPlayer(url, live, ua, (long) resumeMs, fit, type, bufferSecs));
        }

        @JavascriptInterface
        public void previewPlay(final String url, final double x, final double y, final double w, final double h, final double scale, final String ua, final boolean muted, final String type, final double radius) {
            runOnUiThread(() -> startPreview(url, x, y, w, h, scale, ua, muted, type, radius));
        }

        @JavascriptInterface
        public void previewMove(final double x, final double y, final double w, final double h, final double scale) {
            runOnUiThread(() -> { if (previewBox.getVisibility() == View.VISIBLE) placePreview(x, y, w, h, scale); });
        }

        @JavascriptInterface
        public void multiPlay(final int i, final String url, final double x, final double y, final double w, final double h, final double scale, final String ua, final boolean muted, final String type) {
            runOnUiThread(() -> startSlot(i, url, x, y, w, h, scale, ua, muted, type));
        }

        @JavascriptInterface
        public void multiMove(final int i, final double x, final double y, final double w, final double h, final double scale) {
            runOnUiThread(() -> { Slot s = slots.get(i); if (s != null) placeBox(s.box, x, y, w, h, scale); });
        }

        @JavascriptInterface
        public void multiAudio(final int focus) {
            runOnUiThread(() -> {
                for (java.util.Map.Entry<Integer, Slot> e : slots.entrySet()) {
                    if (e.getValue().player != null) e.getValue().player.setVolume(e.getKey() == focus ? 1f : 0f);
                }
            });
        }

        @JavascriptInterface
        public void multiVisible(final boolean visible) {
            runOnUiThread(() -> {
                for (Slot s : slots.values()) s.box.setVisibility(visible && s.player != null ? View.VISIBLE : View.GONE);
            });
        }

        @JavascriptInterface
        public void multiStop(final int i) {
            runOnUiThread(() -> stopSlot(i));
        }

        @JavascriptInterface
        public void multiStopAll() {
            runOnUiThread(MainActivity.this::stopAllSlots);
        }

        @JavascriptInterface
        public void previewStop() {
            runOnUiThread(() -> stopPreview(true));
        }

        @JavascriptInterface
        public void nativeStop() {
            runOnUiThread(MainActivity.this::releasePlayer);
        }

        @JavascriptInterface
        public void nativeToggle() {
            runOnUiThread(() -> { if (player != null) player.setPlayWhenReady(!player.getPlayWhenReady()); });
        }

        @JavascriptInterface
        public void nativeSeekBy(final double ms) {
            runOnUiThread(() -> {
                if (player == null) return;
                long t = Math.max(0, player.getCurrentPosition() + (long) ms);
                long d = player.getDuration();
                if (d != C.TIME_UNSET && d > 0) t = Math.min(t, d - 1000);
                player.seekTo(t);
            });
        }

        @JavascriptInterface
        public void nativeSetFit(final String fit) {
            runOnUiThread(() -> applyFit(fit));
        }

        @JavascriptInterface
        public void nativeSetRate(final double rate) {
            runOnUiThread(() -> { if (player != null) player.setPlaybackSpeed((float) rate); });
        }

        @JavascriptInterface
        public String nativeTracks() {
            return tracksJson;
        }

        @JavascriptInterface
        public void nativeSelectTrack(final int type, final int g, final int i) {
            runOnUiThread(() -> selectTrack(type, g, i));
        }

        @JavascriptInterface
        public boolean isTv() {
            return isTelevision();
        }

        @JavascriptInterface
        public String appVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String platform() {
            return "android " + Build.VERSION.RELEASE;
        }
    }
}
