# Nebula TV for Android TV, Google TV & Fire TV

This folder is a complete Android app. GitHub builds the APK for free, so you don't need Android Studio or any developer tools.

## One-time setup (about 10 minutes)

1. **Make a GitHub repository.** Sign in at github.com → **New repository** → name it `nebula-tv` → **Public** → Create.
   *Public is needed so your TV can download the APK. Your signing key stays secret (step 3), and no playlist logins are stored in the code.*
2. **Upload this folder.** On the new repo page choose **uploading an existing file**, then drag in *everything inside* this folder, including the hidden `.github` folder (on a Mac press Cmd+Shift+. in Finder to show it). Click **Commit changes**.
3. **Add the signing key.** Repo **Settings → Secrets and variables → Actions → New repository secret**
   - Name: `NEBULA_KEYSTORE_B64`
   - Secret: paste the whole contents of `NEBULA_KEYSTORE_B64.txt` (sent separately; keep it private)
4. **Build.** Open the **Actions** tab → **Build Nebula TV APK** → **Run workflow**. It takes about 4 minutes. A green tick means `NebulaTV.apk` is under **Releases**.

Your permanent download link is then:

```
https://github.com/YOUR-USERNAME/nebula-tv/releases/latest/download/NebulaTV.apk
```

## Install on the TV

**Fire TV / Fire Stick**
1. Settings → My Fire TV → **Developer options**. If you can't see it: My Fire TV → About → click your device name 7 times.
2. Turn on **Install unknown apps** for **Downloader**. Install Downloader from the Amazon Appstore first if needed.
3. Open Downloader, type the link above, and choose **Install**.

**Android TV / Google TV (Sony, Philips, TCL, Chromecast with Google TV, Nvidia Shield…)**
1. Install **Downloader by AFTVnews** from the Play Store.
2. Settings → Apps → Security & restrictions → **Unknown sources** → allow Downloader.
3. Open Downloader, enter the link, and install.

Nebula TV then appears on the home screen with its own banner.

## Updating

Upload a new `app/src/main/assets/index.html` to GitHub (or any changed file). A new build starts automatically. Install it over the top with the same link: your playlists and settings are kept because every build uses the same signing key.

## Remote control

| Button | Action |
|---|---|
| D-pad / OK | Move and select everywhere |
| Back | Close menu → leave player → go Home → exit |
| ▲ / ▼ while watching | Mini guide |
| CH+ / CH− | Change channel |
| Number keys | Type a channel number |
| Menu (☰) while watching | Versions of this channel (or quality/audio) |
| Guide button | Mini guide / TV Guide |
| Play/Pause, FF, Rew | On-demand playback |

## What the Android app adds over the browser version
- Playlists and guides download directly with no browser blocking, so no CORS proxy is needed.
- An optional **User agent** setting (Settings → Playback & network) for providers that only allow certain players.
- TV-safe margins, larger focus highlights, keep-screen-on and full-screen playback.

## Building locally instead (optional)
Open this folder in Android Studio → **Build → Build APK(s)**. Local builds use a debug key, so install the GitHub build *or* the local build, not both. The player libraries load from the internet if they weren't bundled.

## Requirements
Android 5.1+ with an up-to-date **Android System WebView** (Fire OS updates this automatically). Some streams use audio or video formats a TV's WebView can't decode. If a channel won't play, try another version of it (the Menu button) or switch the playlist's stream format between HLS and TS.
