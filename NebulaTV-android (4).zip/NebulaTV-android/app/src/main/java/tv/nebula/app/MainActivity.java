package tv.nebula.app;

import android.app.Activity;
import android.media.audiofx.DynamicsProcessing;
import android.app.PictureInPictureParams;
import android.util.Rational;
import androidx.media3.ui.CaptionStyleCompat;
import androidx.media3.ui.SubtitleView;
import androidx.media3.datasource.DefaultDataSource;
import android.app.UiModeManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.speech.RecognizerIntent;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter;
import androidx.tvprovider.media.tv.PreviewChannel;
import androidx.tvprovider.media.tv.PreviewChannelHelper;
import androidx.tvprovider.media.tv.PreviewProgram;
import androidx.tvprovider.media.tv.TvContractCompat;
import androidx.tvprovider.media.tv.WatchNextProgram;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.TextureView;
import android.view.ViewOutlineProvider;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.os.Handler;
import android.os.Looper;
import android.widget.FrameLayout;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.DecoderCounters;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;

/**
 * Nebula TV — a full-screen WebView host for the Nebula TV web app (assets/index.html).
 * The native side adds what a browser can't do: CORS-free downloads of playlists and
 * guides (with an optional custom User-Agent), remote-control keys and the Back button.
 */
public class MainActivity extends Activity {

    private static final int CHUNK = 512 * 1024;

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    // channel checks get their own threads so a long check never holds up the guide or playlists
    private final ExecutorService probePool = Executors.newFixedThreadPool(6);
    private final ConcurrentHashMap<Integer, String> results = new ConcurrentHashMap<>();
    private volatile String userAgent = "";

    // Native (ExoPlayer) video playback, drawn underneath the transparent WebView.
    private PlayerView playerView;
    private ExoPlayer player;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // Small live preview for the TV guide, drawn on top of the WebView.
    private FrameLayout previewBox;
    private AspectRatioFrameLayout previewFrame;
    private TextureView previewTexture;
    private ExoPlayer preview;
    private ExoPlayer fadingOld;

    // Mini TV: the main player's picture moved into a small rounded box over the app.
    private FrameLayout miniBox;
    private AspectRatioFrameLayout miniFrame;
    private TextureView miniTexture;
    private boolean miniOn = false;

    // Deep link from the TV home screen (nebulatv://open?key=...), read by the page when it is ready.
    private volatile String pendingLink = "";
    private static final int VOICE_REQUEST = 77;

    // Viewer preferences applied to every new channel or film.
    private volatile String prefAudio = "";
    private volatile boolean prefSubs = false;

    // Sound: even out loud and quiet channels, or night mode (quieter bangs, clearer speech).
    private volatile String audioMode = "off";
    private DynamicsProcessing dyn;
    private int dynSession = 0;

    // Link with another TV running Nebula: a small always-on web server answering /link.
    private volatile java.net.ServerSocket linkSock;
    private volatile String linkKey = "";

    // Picture-in-picture when the viewer presses Home during a channel or film.
    private volatile boolean pipAllowed = true;
    private boolean inPip = false;

    // Multi-view: several small players, each in its own box over the WebView.
    private FrameLayout root;
    private final java.util.HashMap<Integer, Slot> slots = new java.util.HashMap<>();

    private static class Slot {
        FrameLayout box;
        AspectRatioFrameLayout frame;
        TextureView tex;
        ExoPlayer player;
    }
    private volatile String tracksJson = "[]";
    private volatile long posMs = 0, durMs = 0;
    private boolean currentLive = false;
    // ---- live TV buffer (pause and rewind live) ----
    private Timeshift tshift;
    private boolean tsPlaying = false;      // the player is reading the buffer
    private long tsItemWall = 0;            // when the buffer position the player started from was received
    private long tsPausedAt = 0;            // paused before the buffer was being played
    private String tsUa = "", tsFit = "fit";
    private int tsBufSecs = 30;
    private long tsMaxMs = 60 * 60_000L, tsMaxBytes = 3L << 30;
    private int liveRetries = 0;
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (player == null) return;
            posMs = player.getCurrentPosition();
            long d = player.getDuration();
            durMs = d == C.TIME_UNSET ? 0 : d;
            if (!currentLive) emit("pos", "{\"p\":" + posMs + ",\"d\":" + durMs + "}");
            else if (tshift != null) emit("ts", tsState());
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // keep a note of any crash, so the error log can show it after the app restarts
        final Thread.UncaughtExceptionHandler prevHandler = Thread.getDefaultUncaughtExceptionHandler();
        if (!(prevHandler instanceof CrashNote)) {
            Thread.setDefaultUncaughtExceptionHandler(new CrashNote(getApplicationContext(), prevHandler));
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        goImmersive();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        pool.execute(() -> { try { RecordService.rescheduleAll(getApplicationContext()); } catch (Exception ignored) { } });
        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setShutterBackgroundColor(Color.BLACK);
        playerView.setKeepContentOnPlayerReset(false);
        playerView.setFocusable(false);
        playerView.setVisibility(View.GONE);
        root.addView(playerView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        previewBox = new FrameLayout(this);
        previewBox.setBackgroundColor(Color.BLACK);
        previewBox.setVisibility(View.GONE);
        previewBox.setFocusable(false);
        previewFrame = new AspectRatioFrameLayout(this);
        previewFrame.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        previewTexture = new TextureView(this);
        previewFrame.addView(previewTexture, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        previewBox.addView(previewFrame, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        root.addView(previewBox, new FrameLayout.LayoutParams(1, 1));
        miniBox = new FrameLayout(this);
        miniBox.setBackgroundColor(Color.BLACK);
        miniBox.setVisibility(View.GONE);
        miniBox.setFocusable(false);
        miniFrame = new AspectRatioFrameLayout(this);
        miniFrame.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        miniTexture = new TextureView(this);
        miniFrame.addView(miniTexture, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        miniBox.addView(miniFrame, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        root.addView(miniBox, new FrameLayout.LayoutParams(1, 1));
        setContentView(root);
        String link = linkFrom(getIntent());
        if (link != null) pendingLink = link;

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                try {
                    return imageFor(req);
                } catch (Throwable t) {
                    return null;
                }
            }

            /** The web view's process died (often out of memory on small boxes): note it and start the screen afresh. */
            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                boolean crashed = Build.VERSION.SDK_INT >= 26 && detail != null && detail.didCrash();
                CrashNote.save(getApplicationContext(), crashed ? "The app's screen crashed and was restarted"
                        : "Android closed the app's screen to free memory, so it was restarted", null);
                ui.post(() -> {
                    try { tsStop(); releasePlayer(); stopPreview(); stopAllSlots(); } catch (Exception ignored) { }
                    recreate();
                });
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("file:")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public Bitmap getDefaultVideoPoster() {
                // Hides the grey "play" placeholder Android draws before video starts.
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        });
        web.addJavascriptInterface(new Bridge(), "NebulaNative");
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    private void goImmersive() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    private boolean volMuted = false;
    private boolean okHeld = false;
    private final Runnable okHoldRun = () -> {
        if (web == null) return;
        okHeld = true;
        web.evaluateJavascript("(window.nebulaHold ? window.nebulaHold() : false)", v -> { if (!"true".equals(v)) okHeld = false; });
    };

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) {
                web.evaluateJavascript("(window.nebulaBack ? window.nebulaBack() : false)", value -> {
                    if (!"true".equals(value)) finish();
                });
            }
            return true;
        }
        // Hold OK: some TV WebViews never pass a long press through, so time it here
        if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER || code == KeyEvent.KEYCODE_BUTTON_SELECT) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                if (e.getRepeatCount() == 0) {
                    okHeld = false;
                    ui.removeCallbacks(okHoldRun);
                    ui.postDelayed(okHoldRun, 550);
                } else if (okHeld) {
                    return true;   // already handled as a hold: don't let the repeats click
                }
            } else if (e.getAction() == KeyEvent.ACTION_UP) {
                ui.removeCallbacks(okHoldRun);
                if (okHeld) {
                    okHeld = false;
                    web.evaluateJavascript("window.nebulaHoldEnd && window.nebulaHoldEnd()", null);
                    return true;   // swallow the release so it isn't also a normal press
                }
            }
        }
        String key = null;
        switch (code) {
            case KeyEvent.KEYCODE_CHANNEL_UP: key = "chup"; break;
            case KeyEvent.KEYCODE_CHANNEL_DOWN: key = "chdown"; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: key = "playpause"; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY: key = "play"; break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: key = "pause"; break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: key = "ff"; break;
            case KeyEvent.KEYCODE_MEDIA_REWIND: key = "rw"; break;
            case KeyEvent.KEYCODE_MENU: key = "menu"; break;
            case KeyEvent.KEYCODE_INFO: key = "info"; break;
            case KeyEvent.KEYCODE_GUIDE: key = "guide"; break;
            case KeyEvent.KEYCODE_LAST_CHANNEL: key = "last"; break;
            case KeyEvent.KEYCODE_PROG_RED: key = "red"; break;
            case KeyEvent.KEYCODE_PROG_GREEN: key = "green"; break;
            case KeyEvent.KEYCODE_PROG_YELLOW: key = "yellow"; break;
            case KeyEvent.KEYCODE_PROG_BLUE: key = "blue"; break;
            case KeyEvent.KEYCODE_SEARCH:
            case KeyEvent.KEYCODE_VOICE_ASSIST:
                if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) startVoice();
                return true;
            default: break;
        }
        if (key != null) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
                web.evaluateJavascript("window.nebulaKey && window.nebulaKey('" + key + "')", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String link = linkFrom(intent);
        if (link != null && web != null) {
            web.evaluateJavascript("window.nebulaOpen && window.nebulaOpen(" + JSONObject.quote(link) + ")", null);
        }
    }

    private String linkFrom(Intent intent) {
        if (intent == null) return null;
        Uri data = intent.getData();
        if (data == null || !linkScheme().equals(data.getScheme())) return null;
        String key = data.getQueryParameter("key");
        return (key == null || key.isEmpty() || "home".equals(key)) ? null : key;
    }

    private void startVoice() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a channel, programme or film");
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            startActivityForResult(i, VOICE_REQUEST);
        } catch (ActivityNotFoundException ex) {
            if (web != null) web.evaluateJavascript("window.toast && toast('Voice search is not available on this device','err')", null);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != VOICE_REQUEST || web == null) return;
        String text = "";
        if (resultCode == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty() && r.get(0) != null) text = r.get(0);
        }
        if (resultCode == RESULT_CANCELED && text.isEmpty()) return;
        web.evaluateJavascript("window.__nebulaVoice && window.__nebulaVoice(" + JSONObject.quote(text) + ")", null);
    }

    // ---------- Android TV home screen ----------

    private static String joinIds(java.util.List<Long> ids) {
        StringBuilder b = new StringBuilder();
        for (Long id : ids) { if (b.length() > 0) b.append(','); b.append(id); }
        return b.toString();
    }

    private Uri art(String img) {
        if (img != null && (img.startsWith("http://") || img.startsWith("https://"))) return Uri.parse(img);
        return Uri.parse("android.resource://" + getPackageName() + "/drawable/banner");
    }

    private void publishHomeRows(String json) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            JSONObject o = new JSONObject(json);
            boolean off = o.optBoolean("off", false);
            SharedPreferences sp = getSharedPreferences("home_rows", MODE_PRIVATE);
            PreviewChannelHelper helper = new PreviewChannelHelper(this);

            // Remove what we published last time, then publish fresh rows.
            for (String id : sp.getString("programs", "").split(",")) {
                if (!id.isEmpty()) try { helper.deletePreviewProgram(Long.parseLong(id)); } catch (Exception ignored) { }
            }
            for (String id : sp.getString("watchnext", "").split(",")) {
                if (!id.isEmpty()) try { getContentResolver().delete(TvContractCompat.buildWatchNextProgramUri(Long.parseLong(id)), null, null); } catch (Exception ignored) { }
            }
            java.util.ArrayList<Long> progIds = new java.util.ArrayList<>();
            java.util.ArrayList<Long> wnIds = new java.util.ArrayList<>();
            if (off) {
                sp.edit().putString("programs", "").putString("watchnext", "").apply();
                return;
            }

            long channelId = sp.getLong("channel", -1L);
            if (channelId != -1L) {
                try { if (helper.getPreviewChannel(channelId) == null) channelId = -1L; } catch (Exception ex) { channelId = -1L; }
            }
            if (channelId == -1L) {
                PreviewChannel.Builder cb = new PreviewChannel.Builder()
                        .setDisplayName("Nebula TV: your channels")
                        .setAppLinkIntentUri(Uri.parse(linkScheme() + "://open?key=home"))
                        .setInternalProviderId("nebula-favs");
                Bitmap logo = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
                if (logo != null) cb.setLogo(logo);
                channelId = helper.publishChannel(cb.build());
                sp.edit().putLong("channel", channelId).apply();
                try { TvContractCompat.requestChannelBrowsable(this, channelId); } catch (Exception ignored) { }
            }

            JSONArray favs = o.optJSONArray("favs");
            if (favs != null) {
                for (int i = 0; i < favs.length(); i++) {
                    JSONObject f = favs.getJSONObject(i);
                    PreviewProgram.Builder pb = new PreviewProgram.Builder();
                    pb.setChannelId(channelId)
                            .setType(TvContractCompat.PreviewPrograms.TYPE_CHANNEL)
                            .setTitle(f.optString("title"))
                            .setDescription(f.optString("desc"))
                            .setPosterArtUri(art(f.optString("img")))
                            .setPosterArtAspectRatio(TvContractCompat.PreviewPrograms.ASPECT_RATIO_16_9)
                            .setIntentUri(Uri.parse(f.optString("link")))
                            .setInternalProviderId(f.optString("id"))
                            .setWeight(favs.length() - i)
                            .setLive(true);
                    progIds.add(helper.publishPreviewProgram(pb.build()));
                }
            }

            JSONArray wn = o.optJSONArray("watchNext");
            if (wn != null) {
                for (int i = 0; i < wn.length(); i++) {
                    JSONObject w = wn.getJSONObject(i);
                    String kind = w.optString("kind");
                    int type = "live".equals(kind) ? TvContractCompat.WatchNextPrograms.TYPE_CHANNEL
                            : "episode".equals(kind) ? TvContractCompat.WatchNextPrograms.TYPE_TV_EPISODE
                            : TvContractCompat.WatchNextPrograms.TYPE_MOVIE;
                    WatchNextProgram.Builder wb = new WatchNextProgram.Builder();
                    wb.setWatchNextType(TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE)
                            .setLastEngagementTimeUtcMillis(w.optLong("t", System.currentTimeMillis()))
                            .setType(type)
                            .setTitle(w.optString("title"))
                            .setDescription(w.optString("desc"))
                            .setPosterArtUri(art(w.optString("img")))
                            .setPosterArtAspectRatio(TvContractCompat.WatchNextPrograms.ASPECT_RATIO_16_9)
                            .setIntentUri(Uri.parse(w.optString("link")))
                            .setInternalProviderId(w.optString("id"));
                    if (w.has("dur")) {
                        wb.setDurationMillis(w.optInt("dur"));
                        wb.setLastPlaybackPositionMillis(w.optInt("pos"));
                    }
                    wnIds.add(helper.publishWatchNextProgram(wb.build()));
                }
            }
            sp.edit().putString("programs", joinIds(progIds)).putString("watchnext", joinIds(wnIds)).apply();
        } catch (Throwable t) {
            // The home screen is a bonus: devices without it (e.g. Fire TV) simply ignore this.
        }
    }

    private void setMini(double x, double y, double w, double h, double scale, double radius) {
        if (w <= 0 || h <= 0) {
            if (miniOn) {
                miniOn = false;
                if (player != null) {
                    player.clearVideoTextureView(miniTexture);
                    playerView.setPlayer(player);
                }
            }
            miniBox.setVisibility(View.GONE);
            return;
        }
        placeBox(miniBox, x, y, w, h, scale);
        roundCorners(miniBox, (float) (radius * scale));
        miniBox.setVisibility(View.VISIBLE);
        miniBox.bringToFront();
        if (player != null && !miniOn) {
            miniOn = true;
            VideoSize vs = player.getVideoSize();
            if (vs.height > 0) miniFrame.setAspectRatio(vs.width * vs.pixelWidthHeightRatio / vs.height);
            playerView.setPlayer(null);
            player.setVideoTextureView(miniTexture);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        ui.removeCallbacks(tsBgStop);
        web.evaluateJavascript("window.nebulaResume && window.nebulaResume()", null);
        web.evaluateJavascript("window.vpnPoll && window.vpnPoll()", null);
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        enterPipIfPlaying();
    }

    private void enterPipIfPlaying() {
        if (!pipAllowed || Build.VERSION.SDK_INT < 26 || player == null || !player.isPlaying()) return;
        if (playerView == null || playerView.getVisibility() != View.VISIBLE || miniOn) return;
        try {
            if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return;
            VideoSize v = player.getVideoSize();
            Rational ratio = new Rational(16, 9);
            if (v.width > 0 && v.height > 0) {
                double r = v.width * (double) v.pixelWidthHeightRatio / v.height;
                if (r > 0.42 && r < 2.38) ratio = new Rational((int) Math.round(r * 1000), 1000);
            }
            enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(ratio).build());
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPip, newConfig);
        inPip = isInPip;
        if (isInPip) {
            stopPreview();
            stopAllSlots();
        }
        if (web != null) {
            web.setVisibility(isInPip ? View.INVISIBLE : View.VISIBLE);
            web.evaluateJavascript("window.__nebulaPip && window.__nebulaPip(" + isInPip + ")", null);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
        stopPreview();
        stopAllSlots();
        // don't hold the provider connection for long while the app is in the background
        if (tshift != null) ui.postDelayed(tsBgStop, 5 * 60_000L);
        emit("appStopped", null);
    }

    @Override
    protected void onDestroy() {
        stopRemote();
        java.net.ServerSocket ls = linkSock;
        linkSock = null;
        if (ls != null) try { ls.close(); } catch (IOException ignored) { }
        if (dyn != null) try { dyn.release(); } catch (Exception ignored) { }
        stopPreview();
        stopAllSlots();
        tsStop();
        releasePlayer();
        pool.shutdownNow();
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    // ---------- channel logos and artwork ----------
    // Images are fetched natively (custom User-Agent, http/https redirects) and kept on disk for a week,
    // so logos appear instantly on later visits and don't depend on the TV's web view.

    private static final long IMG_MAX_AGE = 7L * 24 * 3600 * 1000;

    private static boolean looksLikeImage(WebResourceRequest req) {
        String accept = req.getRequestHeaders() == null ? null : req.getRequestHeaders().get("Accept");
        if (accept != null && accept.startsWith("image/")) return true;
        String path = req.getUrl().getPath();
        if (path == null) return false;
        path = path.toLowerCase(java.util.Locale.ROOT);
        return path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".webp") || path.endsWith(".gif") || path.endsWith(".svg");
    }

    private static String sha1(String s) throws Exception {
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
        byte[] d = md.digest(s.getBytes("UTF-8"));
        StringBuilder b = new StringBuilder();
        for (byte x : d) b.append(String.format("%02x", x));
        return b.toString();
    }

    private static String guessMime(String url, String header) {
        if (header != null && header.startsWith("image/")) return header.split(";")[0].trim();
        String u = url.toLowerCase(java.util.Locale.ROOT);
        if (u.contains(".svg")) return "image/svg+xml";
        if (u.contains(".jpg") || u.contains(".jpeg")) return "image/jpeg";
        if (u.contains(".webp")) return "image/webp";
        if (u.contains(".gif")) return "image/gif";
        return "image/png";
    }

    private WebResourceResponse imgResponse(String mime, byte[] body, int status) {
        java.util.HashMap<String, String> h = new java.util.HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "max-age=604800");
        return new WebResourceResponse(mime, null, status, status == 200 ? "OK" : "Not Found", h, new java.io.ByteArrayInputStream(body));
    }

    private WebResourceResponse imageFor(WebResourceRequest req) throws Exception {
        if (!"GET".equalsIgnoreCase(req.getMethod())) return null;
        String scheme = req.getUrl().getScheme();
        if (!"http".equals(scheme) && !"https".equals(scheme)) return null;
        if (!looksLikeImage(req)) return null;
        String url = req.getUrl().toString();
        java.io.File dir = new java.io.File(getCacheDir(), "img");
        if (!dir.exists()) dir.mkdirs();
        String key = sha1(url);
        java.io.File f = new java.io.File(dir, key);
        java.io.File mf = new java.io.File(dir, key + ".m");
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < IMG_MAX_AGE) {
            String mime = mf.exists() ? new String(readAll(new java.io.FileInputStream(mf)), "UTF-8") : guessMime(url, null);
            return imgResponse(mime, readAll(new java.io.FileInputStream(f)), 200);
        }
        String current = url;
        for (int hop = 0; hop < 6; hop++) {
            URL u = new URL(current);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(8000);
            c.setReadTimeout(15000);
            String agent = userAgent.isEmpty() ? System.getProperty("http.agent") : userAgent;
            if (agent != null) c.setRequestProperty("User-Agent", agent);
            c.setRequestProperty("Accept", "image/*,*/*;q=0.8");
            int status;
            try {
                status = c.getResponseCode();
            } catch (Exception ex) {
                c.disconnect();
                return imgResponse("image/png", new byte[0], 404);
            }
            if (status >= 300 && status < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) break;
                current = new URL(u, loc).toString();
                continue;
            }
            if (status != 200) {
                c.disconnect();
                break;
            }
            String type = c.getContentType();
            if (type != null && (type.startsWith("text/html") || type.startsWith("application/json"))) {
                c.disconnect();
                break;
            }
            byte[] body = readAll(c.getInputStream());
            c.disconnect();
            if (body.length == 0 || body.length > 4 * 1024 * 1024) break;
            String mime = guessMime(current, type);
            try {
                java.io.FileOutputStream o = new java.io.FileOutputStream(f);
                o.write(body);
                o.close();
                java.io.FileOutputStream m = new java.io.FileOutputStream(mf);
                m.write(mime.getBytes("UTF-8"));
                m.close();
            } catch (Exception ignored) {
            }
            return imgResponse(mime, body, 200);
        }
        // An old copy is better than nothing if the server is down.
        if (f.exists()) {
            String mime = mf.exists() ? new String(readAll(new java.io.FileInputStream(mf)), "UTF-8") : guessMime(url, null);
            return imgResponse(mime, readAll(new java.io.FileInputStream(f)), 200);
        }
        return imgResponse("image/png", new byte[0], 404);
    }

    private static byte[] readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    private String download(String address, String ua) throws Exception {
        String current = address;
        for (int hop = 0; hop < 8; hop++) {
            URL url = new URL(current);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(90000);
            String agent = (ua != null && !ua.isEmpty()) ? ua : (userAgent.isEmpty() ? System.getProperty("http.agent") : userAgent);
            if (agent != null) c.setRequestProperty("User-Agent", agent);
            c.setRequestProperty("Accept-Encoding", "gzip");
            int status = c.getResponseCode();
            if (status >= 300 && status < 400) {
                String location = c.getHeaderField("Location");
                c.disconnect();
                if (location == null) throw new IOException("Redirect without a location");
                current = new URL(url, location).toString();
                continue;
            }
            if (status >= 400) {
                c.disconnect();
                throw new IOException("Server replied HTTP " + status);
            }
            InputStream in = new BufferedInputStream(c.getInputStream(), 65536);
            in.mark(4);
            int b1 = in.read();
            int b2 = in.read();
            in.reset();
            if (b1 == 0x1f && b2 == 0x8b) in = new GZIPInputStream(in, 65536);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            c.disconnect();
            return out.toString("UTF-8");
        }
        throw new IOException("Too many redirects");
    }

    // ---------- native playback ----------

    private void emit(String type, String json) {
        if (web == null) return;
        web.evaluateJavascript("window.__nebulaPlayer && window.__nebulaPlayer('" + type + "'," + (json == null ? "null" : json) + ")", null);
    }

    private void releasePlayer() {
        ui.removeCallbacks(ticker);
        if (player != null) {
            player.release();
            player = null;
        }
        if (playerView != null) {
            playerView.setPlayer(null);
            playerView.setVisibility(View.GONE);
        }
        miniOn = false;
        if (miniBox != null) miniBox.setVisibility(View.GONE);
        tracksJson = "[]";
        posMs = 0;
        durMs = 0;
    }

    private void applyFit(String fit) {
        if (playerView == null) return;
        int mode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
        if ("cover".equals(fit)) mode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM;
        else if ("fill".equals(fit)) mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
        playerView.setResizeMode(mode);
    }

    private DefaultMediaSourceFactory buildSources(String ua) {
        String agent = (ua != null && !ua.isEmpty()) ? ua : (userAgent.isEmpty() ? System.getProperty("http.agent") : userAgent);
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000);
        if (agent != null && !agent.isEmpty()) http.setUserAgent(agent);
        DefaultExtractorsFactory extractors = extractors();
        // DefaultDataSource also reads local files, so recordings play through the same player.
        DefaultDataSource.Factory data = new DefaultDataSource.Factory(this, http);
        return new DefaultMediaSourceFactory(data, extractors)
                .setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(8));
    }

    private DefaultExtractorsFactory extractors() {
        return new DefaultExtractorsFactory()
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
                .setConstantBitrateSeekingEnabled(true);
    }

    private MediaItem buildItem(String url, String type) {
        MediaItem.Builder item = new MediaItem.Builder().setUri(Uri.parse(url));
        if ("hls".equals(type)) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if ("ts".equals(type)) item.setMimeType(MimeTypes.VIDEO_MP2T);
        return item.build();
    }

    private void placePreview(double x, double y, double w, double h, double scale) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) Math.round(w * scale), (int) Math.round(h * scale));
        lp.leftMargin = (int) Math.round(x * scale);
        lp.topMargin = (int) Math.round(y * scale);
        lp.gravity = Gravity.TOP | Gravity.START;
        previewBox.setLayoutParams(lp);
    }

    private Slot slot(int i) {
        Slot s = slots.get(i);
        if (s == null) {
            s = new Slot();
            s.box = new FrameLayout(this);
            s.box.setBackgroundColor(Color.BLACK);
            s.box.setVisibility(View.GONE);
            s.box.setFocusable(false);
            s.frame = new AspectRatioFrameLayout(this);
            s.frame.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            s.tex = new TextureView(this);
            s.frame.addView(s.tex, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            s.box.addView(s.frame, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            root.addView(s.box, new FrameLayout.LayoutParams(1, 1));
            slots.put(i, s);
        }
        return s;
    }

    private void placeBox(View box, double x, double y, double w, double h, double scale) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) Math.round(w * scale), (int) Math.round(h * scale));
        lp.leftMargin = (int) Math.round(x * scale);
        lp.topMargin = (int) Math.round(y * scale);
        lp.gravity = Gravity.TOP | Gravity.START;
        box.setLayoutParams(lp);
    }

    private void stopSlot(int i) {
        Slot s = slots.get(i);
        if (s == null) return;
        if (s.player != null) {
            s.player.release();
            s.player = null;
        }
        s.box.setVisibility(View.GONE);
    }

    private void stopAllSlots() {
        for (Integer i : new java.util.ArrayList<>(slots.keySet())) stopSlot(i);
    }

    private void startSlot(final int i, String url, double x, double y, double w, double h, double scale, String ua, boolean muted, String type) {
        final Slot s = slot(i);
        if (s.player != null) {
            s.player.release();
            s.player = null;
        }
        placeBox(s.box, x, y, w, h, scale);
        roundCorners(s.box, (float) (9 * scale));
        s.box.setAlpha(0f);
        s.box.setVisibility(View.VISIBLE);
        DefaultLoadControl load = new DefaultLoadControl.Builder().setBufferDurationsMs(10000, 30000, 1500, 3000).build();
        s.player = new ExoPlayer.Builder(this, new DefaultRenderersFactory(this).setEnableDecoderFallback(true))
                .setMediaSourceFactory(buildSources(ua))
                .setLoadControl(load)
                .build();
        s.player.setVideoTextureView(s.tex);
        s.player.setVolume(muted ? 0f : 1f);
        s.player.addListener(new Player.Listener() {
            @Override
            public void onVideoSizeChanged(VideoSize size) {
                if (size.height > 0) s.frame.setAspectRatio(size.width * size.pixelWidthHeightRatio / size.height);
            }

            @Override
            public void onRenderedFirstFrame() {
                s.box.animate().alpha(1f).setDuration(500).start();
            }

            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) emit("multiReady", String.valueOf(i));
                else if (state == Player.STATE_BUFFERING) emit("multiBuffering", String.valueOf(i));
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (s.player != null) {
                    s.player.release();
                    s.player = null;
                }
                emit("multiError", String.valueOf(i));
            }
        });
        s.player.setMediaItem(buildItem(url, type));
        s.player.setPlayWhenReady(true);
        s.player.prepare();
    }

    private void roundCorners(View v, final float radiusPx) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
        v.setClipToOutline(true);
    }

    private void stopPreview() {
        stopPreview(false);
    }

    /** Stops the guide/home preview; with fade, the picture dissolves back to the logo underneath. */
    private void stopPreview(boolean fade) {
        if (previewBox == null) return;
        previewBox.animate().cancel();
        // Cancelling the fade skips its clean-up, so finish it here or the old picture stays on screen.
        if (!fade && fadingOld != null) {
            fadingOld.release();
            fadingOld = null;
        }
        if (preview == null) {
            if (fadingOld == null) previewBox.setVisibility(View.GONE);
            return;
        }
        final ExoPlayer old = preview;
        preview = null;
        if (!fade || previewBox.getVisibility() != View.VISIBLE || previewBox.getAlpha() < 0.05f) {
            old.release();
            previewBox.setVisibility(View.GONE);
            return;
        }
        fadingOld = old;
        previewBox.animate().alpha(0f).setDuration(450).withEndAction(() -> {
            if (fadingOld == old) {
                old.release();
                fadingOld = null;
            }
            if (preview == null) previewBox.setVisibility(View.GONE);
        }).start();
    }

    private void startPreview(String url, double x, double y, double w, double h, double scale, String ua, boolean muted, String type, double radius) {
        previewBox.animate().cancel();
        if (fadingOld != null) {
            fadingOld.release();
            fadingOld = null;
        }
        stopPreview(false);
        placePreview(x, y, w, h, scale);
        roundCorners(previewBox, (float) (radius * scale));
        previewBox.setAlpha(0f);
        previewBox.setVisibility(View.VISIBLE);
        DefaultLoadControl load = new DefaultLoadControl.Builder().setBufferDurationsMs(8000, 20000, 1000, 2000).build();
        preview = new ExoPlayer.Builder(this, new DefaultRenderersFactory(this).setEnableDecoderFallback(true))
                .setMediaSourceFactory(buildSources(ua))
                .setLoadControl(load)
                .build();
        preview.setVideoTextureView(previewTexture);
        preview.setVolume(muted ? 0f : 1f);
        preview.addListener(new Player.Listener() {
            @Override
            public void onVideoSizeChanged(VideoSize size) {
                if (size.height > 0) previewFrame.setAspectRatio(size.width * size.pixelWidthHeightRatio / size.height);
            }

            @Override
            public void onRenderedFirstFrame() {
                previewBox.animate().alpha(1f).setDuration(650).start();
                emit("previewReady", null);
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                stopPreview(true);
                emit("previewError", null);
            }
        });
        preview.setMediaItem(buildItem(url, type));
        preview.setPlayWhenReady(true);
        preview.prepare();
    }

    private void startPlayer(String url, boolean live, String ua, long resumeMs, String fit, String type, int bufferSecs) {
        startPlayer(url, live, ua, resumeMs, fit, type, bufferSecs, null);
    }

    private void startPlayer(String url, boolean live, String ua, long resumeMs, String fit, String type, int bufferSecs, MediaSource bufSrc) {
        stopPreview();
        stopAllSlots();
        releasePlayer();
        if (bufSrc == null) {
            tsStop();
            if (playerView != null) playerView.setKeepContentOnPlayerReset(false);
        }
        tsPlaying = bufSrc != null;
        currentLive = live;
        liveRetries = 0;
        DefaultMediaSourceFactory sources = buildSources(ua);
        int maxBuf = Math.max(50000, bufferSecs * 1000);

        int minBuf = Math.min(maxBuf, Math.max(15000, bufferSecs * 500));
        DefaultLoadControl load = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(minBuf, maxBuf, 2000, 4000)
                .build();
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this).setEnableDecoderFallback(true);
        player = new ExoPlayer.Builder(this, renderers)
                .setMediaSourceFactory(sources)
                .setLoadControl(load)
                .build();
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) emit("buffering", null);
                else if (state == Player.STATE_READY) { liveRetries = 0; emit("playing", null); }
                else if (state == Player.STATE_ENDED) emit("ended", null);
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                emit(isPlaying ? "play" : "pause", null);
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (player == null) return;
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                boolean network = error.errorCode >= 2000 && error.errorCode < 3000;
                if (tsPlaying && tshift != null && tshift.failed()) {
                    String m = "Live buffer: " + tshift.error();
                    tsStop();
                    emit("error", JSONObject.quote(m));
                    return;
                }
                if (currentLive && network && liveRetries < 3) {
                    liveRetries++;
                    ui.postDelayed(() -> { if (player != null) player.prepare(); }, 1000L * liveRetries);
                    return;
                }
                String m = error.getErrorCodeName() + (error.getMessage() == null ? "" : ": " + error.getMessage());
                emit("error", JSONObject.quote(m));
            }

            @Override
            public void onTracksChanged(Tracks tracks) {
                tracksJson = buildTracks(tracks);
                emit("tracks", null);
            }

            @Override
            public void onVideoSizeChanged(VideoSize size) {
                if (size.height > 0) miniFrame.setAspectRatio(size.width * size.pixelWidthHeightRatio / size.height);
            }

            @Override
            public void onAudioSessionIdChanged(int audioSessionId) {
                applyAudioMode(audioSessionId);
            }
        });
        applyPrefs();
        try { applyAudioMode(player.getAudioSessionId()); } catch (Exception ignored) { }
        applyFit(fit);
        playerView.setPlayer(player);
        playerView.setVisibility(View.VISIBLE);
        if (bufSrc != null) player.setMediaSource(bufSrc);
        else if (resumeMs > 0) player.setMediaItem(buildItem(url, type), resumeMs);
        else player.setMediaItem(buildItem(url, type));
        player.setPlayWhenReady(true);
        player.prepare();
        ui.post(ticker);
    }

    // ---------- live TV buffer ----------

    private final Runnable tsBgStop = () -> {
        if (tshift != null) {
            tsStop();
            emit("tsStopped", null);
        }
    };

    private void tsStop() {
        if (tshift != null) tshift.stop();
        tshift = null;
        tsPlaying = false;
        tsPausedAt = 0;
    }

    /** Starts buffering a channel, or keeps the buffer already running for it. */
    private Timeshift tsEnsure(String url, String ua, String type) {
        if (tshift != null && !tshift.stopped() && tshift.url.equals(url)) return tshift;
        if (tshift != null) tshift.stop();
        File dir = new File(getCacheDir(), "timeshift");
        long free = dir.getParentFile() == null ? 0 : dir.getParentFile().getUsableSpace();
        long room = Math.max(96L << 20, Math.min(tsMaxBytes, free / 2));   // never more than half the free space
        tshift = new Timeshift(url, ua, type, dir, tsMaxMs, room);
        tshift.start();
        return tshift;
    }

    private MediaSource tsSource(long wall) {
        long off = tshift.offsetAt(wall);
        tsItemWall = tshift.wallAt(off);
        return new ProgressiveMediaSource.Factory(new TimeshiftDataSource.Factory(tshift), extractors())
                .createMediaSource(new MediaItem.Builder().setUri(TimeshiftDataSource.uriFor(off)).build());
    }

    /** Plays the buffer from the moment received at a given time. */
    private void tsPlayFrom(long wall, boolean playing) {
        if (tshift == null) return;
        tsPausedAt = 0;
        MediaSource src = tsSource(wall);
        if (player != null && tsPlaying) {
            player.setMediaSource(src);
            player.prepare();
            player.setPlayWhenReady(playing);
        } else {
            String u = tshift.url;
            startPlayer(u, true, tsUa, 0, tsFit, "ts", tsBufSecs, src);
            if (player != null) player.setPlayWhenReady(playing);
        }
    }

    /** The moment of the channel on screen now, as a wall-clock time. */
    private long tsWallNow() {
        if (tsPausedAt > 0) return tsPausedAt;
        if (player == null || !tsPlaying) return System.currentTimeMillis();
        return tsItemWall + Math.max(0, player.getCurrentPosition());
    }

    private String tsState() {
        JSONObject o = new JSONObject();
        try {
            long now = System.currentTimeMillis();
            Timeshift t = tshift;
            if (t == null) return "null";
            long pos = tsWallNow();
            o.put("on", tsPlaying);
            o.put("pending", tsPausedAt > 0);
            o.put("paused", tsPausedAt > 0 || (player != null && !player.getPlayWhenReady()));
            o.put("behind", Math.max(0, now - pos));
            o.put("win", Math.max(0, now - t.earliestWall()));
            o.put("bytes", t.written());
            o.put("ready", t.firstData() > 0);
            o.put("fail", t.failed());
            o.put("err", t.error());
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    /**
     * Volume levelling and night mode, using Android's built-in dynamics processor (Android 9+).
     * Level: a gentle compressor so adverts and loud channels sit closer to the rest.
     * Night: stronger compression, less deep bass and a lift for speech, so it's easy to follow quietly.
     */
    private void applyAudioMode(int session) {
        if (Build.VERSION.SDK_INT < 28) return;
        try {
            if (dyn != null && (session != dynSession || "off".equals(audioMode))) {
                dyn.release();
                dyn = null;
            }
            if ("off".equals(audioMode) || session == 0 || session == C.AUDIO_SESSION_ID_UNSET) return;
            boolean night = "night".equals(audioMode);
            DynamicsProcessing.Config cfg = new DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
                    true, 3, true, 1, false, 0, true).build();
            // speech is mostly 250 Hz to 4 kHz
            cfg.setPreEqBandAllChannelsTo(0, new DynamicsProcessing.EqBand(true, 250f, night ? -5f : 0f));
            cfg.setPreEqBandAllChannelsTo(1, new DynamicsProcessing.EqBand(true, 4000f, night ? 3f : 0f));
            cfg.setPreEqBandAllChannelsTo(2, new DynamicsProcessing.EqBand(true, 20000f, 0f));
            cfg.setMbcBandAllChannelsTo(0, new DynamicsProcessing.MbcBand(true, 20000f, 8f, 250f,
                    night ? 6f : 3f, night ? -32f : -24f, 8f, -90f, 1f, 0f, night ? 10f : 6f));
            cfg.setLimiterAllChannelsTo(new DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f));
            if (dyn != null) dyn.release();
            dyn = new DynamicsProcessing(0, session, cfg);
            dyn.setEnabled(true);
            dynSession = session;
        } catch (Throwable e) {
            dyn = null;
        }
    }

    private void applySubStyle(double size, String fg, String bg, String edge) {
        if (playerView == null) return;
        try {
            SubtitleView sv = playerView.getSubtitleView();
            if (sv == null) return;
            int edgeType = "outline".equals(edge) ? CaptionStyleCompat.EDGE_TYPE_OUTLINE
                    : "shadow".equals(edge) ? CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW : CaptionStyleCompat.EDGE_TYPE_NONE;
            sv.setApplyEmbeddedStyles(false);
            sv.setApplyEmbeddedFontSizes(false);
            sv.setStyle(new CaptionStyleCompat(Color.parseColor(fg), Color.parseColor(bg), Color.TRANSPARENT, edgeType, Color.BLACK, null));
            sv.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * (float) Math.max(0.5, Math.min(2.5, size)));
        } catch (Exception ignored) {
        }
    }

    private void applyPrefs() {
        if (player == null) return;
        try {
            TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
            if (!prefAudio.isEmpty()) b.setPreferredAudioLanguage(prefAudio);
            if (prefSubs) {
                b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false);
                b.setPreferredTextLanguage(prefAudio.isEmpty() ? "en" : prefAudio);
                b.setSelectUndeterminedTextLanguage(true);
            } else {
                b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
            }
            player.setTrackSelectionParameters(b.build());
        } catch (Exception ignored) {
        }
    }

    private String statsJson() {
        JSONObject o = new JSONObject();
        try {
            if (player == null) return "null";
            Format v = player.getVideoFormat();
            Format a = player.getAudioFormat();
            if (v != null) {
                o.put("w", v.width);
                o.put("h", v.height);
                o.put("fps", v.frameRate);
                o.put("vcodec", v.codecs != null ? v.codecs : (v.sampleMimeType == null ? "" : v.sampleMimeType));
                o.put("vbr", v.bitrate);
            }
            if (a != null) {
                o.put("acodec", a.codecs != null ? a.codecs : (a.sampleMimeType == null ? "" : a.sampleMimeType));
                o.put("ach", a.channelCount);
            }
            o.put("buf", player.getTotalBufferedDuration());
            DecoderCounters dc = player.getVideoDecoderCounters();
            if (dc != null) {
                dc.ensureUpdated();
                o.put("dropped", dc.droppedBufferCount);
                o.put("rendered", dc.renderedOutputBufferCount);
            }
            o.put("bw", DefaultBandwidthMeter.getSingletonInstance(this).getBitrateEstimate());
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    /** Device, memory, connections and buffer figures for the System information page. */
    private String sysJson() {
        JSONObject o = new JSONObject();
        try {
            JSONObject c = new JSONObject();
            c.put("player", player != null && !(tsPlaying || tshift != null) && player.getPlaybackState() != Player.STATE_IDLE ? 1 : 0);
            c.put("buffer", tshift != null && !tshift.stopped() && !tshift.failed() ? 1 : 0);
            c.put("preview", preview != null ? 1 : 0);
            int multi = 0;
            for (Slot sl : slots.values()) if (sl.player != null) multi++;
            c.put("multi", multi);
            c.put("recordings", RecordService.active.size());
            o.put("conns", c);
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                o.put("memAvail", mi.availMem);
                o.put("memTotal", mi.totalMem);
                o.put("memLow", mi.lowMemory);
                o.put("memClass", am.getMemoryClass());
            }
            Runtime rt = Runtime.getRuntime();
            o.put("heapUsed", rt.totalMemory() - rt.freeMemory());
            o.put("heapMax", rt.maxMemory());
            o.put("cacheFree", getCacheDir().getUsableSpace());
            o.put("cacheTotal", getCacheDir().getTotalSpace());
            if (tshift != null) {
                o.put("tsBytes", tshift.written() - tshift.earliestOffset());
                o.put("tsWin", System.currentTimeMillis() - tshift.earliestWall());
            }
            o.put("tsMaxMin", tsMaxMs / 60000);
            o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            o.put("android", Build.VERSION.RELEASE);
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("cpus", rt.availableProcessors());
            o.put("abi", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            o.put("screen", dm.widthPixels + "x" + dm.heightPixels);
            o.put("density", dm.densityDpi);
            o.put("uptime", android.os.SystemClock.elapsedRealtime());
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    private void runSpeedTest(String address) {
        double mbps = -1;
        try {
            URL u = new URL(address);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setUseCaches(false);
            InputStream in = c.getInputStream();
            byte[] buf = new byte[65536];
            long n = 0, t0 = System.nanoTime();
            int r;
            while ((r = in.read(buf)) > 0) {
                n += r;
                if (System.nanoTime() - t0 > 8_000_000_000L) break;
            }
            double secs = (System.nanoTime() - t0) / 1e9;
            in.close();
            c.disconnect();
            if (secs > 0 && n > 0) mbps = n * 8 / secs / 1e6;
        } catch (Exception ignored) {
        }
        final String js = "window.__nebulaSpeed && window.__nebulaSpeed(" + mbps + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    // ---------- phone remote: a tiny web server on the home network ----------

    private volatile java.net.ServerSocket remoteSock;
    private volatile String remoteKey = "", remoteHtml = "", remoteBackup = "";

    private static String localIp() {
        String fallback = "";
        try {
            for (java.net.NetworkInterface ni : java.util.Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (java.net.InetAddress a : java.util.Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof java.net.Inet4Address) || a.isLoopbackAddress()) continue;
                    String ip = a.getHostAddress();
                    String n = ni.getName() == null ? "" : ni.getName();
                    if (a.isSiteLocalAddress() && (n.startsWith("wlan") || n.startsWith("eth"))) return ip;
                    if (a.isSiteLocalAddress() && (fallback.isEmpty() || !fallback.startsWith("site:"))) fallback = "site:" + ip;
                    else if (fallback.isEmpty()) fallback = ip;
                }
            }
        } catch (Exception ignored) {
        }
        return fallback.startsWith("site:") ? fallback.substring(5) : fallback;
    }

    private String startRemote(String key, String html, String backup) {
        // already running with the same code: just refresh the page and setup copy, so phones stay connected
        java.net.ServerSocket running = remoteSock;
        if (running != null && !running.isClosed() && key != null && key.equals(remoteKey)) {
            remoteHtml = html == null ? "" : html;
            remoteBackup = backup == null ? "" : backup;
            String ip = localIp();
            if (!ip.isEmpty()) return ip + ":" + running.getLocalPort();
        }
        stopRemote();
        remoteKey = key == null ? "" : key;
        remoteHtml = html == null ? "" : html;
        remoteBackup = backup == null ? "" : backup;
        String ip = localIp();
        if (ip.isEmpty() || remoteKey.length() < 4) return "";
        for (int port = 8642; port < 8652; port++) {
            try {
                final java.net.ServerSocket ss = new java.net.ServerSocket(port);
                remoteSock = ss;
                Thread t = new Thread(() -> {
                    while (!ss.isClosed()) {
                        try {
                            final java.net.Socket sock = ss.accept();
                            new Thread(() -> handleRemote(sock), "nebula-remote-conn").start();
                        } catch (IOException e) {
                            break;
                        }
                    }
                }, "nebula-remote");
                t.setDaemon(true);
                t.start();
                return ip + ":" + port;
            } catch (IOException ignored) {
            }
        }
        return "";
    }

    private String startLink(String key) {
        if (key == null || key.length() < 6) return "";
        String ip = localIp();
        if (ip.isEmpty()) return "";
        java.net.ServerSocket cur = linkSock;
        if (cur != null && !cur.isClosed() && key.equals(linkKey)) return ip + ":" + cur.getLocalPort();
        if (cur != null) try { cur.close(); } catch (IOException ignored) { }
        linkKey = key;
        for (int port = 8660; port < 8670; port++) {
            try {
                final java.net.ServerSocket ss = new java.net.ServerSocket(port);
                linkSock = ss;
                Thread t = new Thread(() -> {
                    while (!ss.isClosed()) {
                        try {
                            final java.net.Socket sock = ss.accept();
                            new Thread(() -> handleLink(sock), "nebula-link-conn").start();
                        } catch (IOException e) {
                            break;
                        }
                    }
                }, "nebula-link");
                t.setDaemon(true);
                t.start();
                return ip + ":" + port;
            } catch (IOException ignored) {
            }
        }
        return "";
    }

    private void handleLink(java.net.Socket sock) {
        try {
            sock.setSoTimeout(15000);
            InputStream in = new BufferedInputStream(sock.getInputStream());
            ByteArrayOutputStream head = new ByteArrayOutputStream();
            int b, last4 = 0;
            while ((b = in.read()) != -1) {
                head.write(b);
                last4 = (last4 << 8) | (b & 0xff);
                if (last4 == 0x0d0a0d0a || head.size() > 32768) break;
            }
            String[] lines = head.toString("UTF-8").split("\r\n");
            String[] req = lines.length > 0 ? lines[0].split(" ") : new String[0];
            if (req.length < 2) { sock.close(); return; }
            String target = req[1], path = target, query = "";
            int q = target.indexOf('?');
            if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }
            if (linkKey.isEmpty() || !linkKey.equals(queryParam(query, "k"))) {
                sendHttp(sock, 403, "text/plain", "Not linked", null);
                return;
            }
            if ("/rec".equals(path)) {          // a linked TV watching one of this TV's recordings
                String range = "";
                for (String l : lines) if (l.toLowerCase(java.util.Locale.ROOT).startsWith("range:")) range = l.substring(6).trim();
                serveRecording(sock, queryParam(query, "id"), range, req[0]);
                return;
            }
            if (!"/link".equals(path)) {
                sendHttp(sock, 404, "text/plain", "Not found", null);
                return;
            }
            final String text = query;
            final String[] out = {"{\"ok\":false}"};
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(() -> {
                if (web == null) { done.countDown(); return; }
                web.evaluateJavascript("window.__nebulaLink ? window.__nebulaLink(" + JSONObject.quote(text) + ") : ''", v -> {
                    try {
                        Object o = new org.json.JSONTokener(v).nextValue();
                        if (o instanceof String && !((String) o).isEmpty()) out[0] = (String) o;
                    } catch (Exception ignored) {
                    }
                    done.countDown();
                });
            });
            done.await(8, java.util.concurrent.TimeUnit.SECONDS);
            sendHttp(sock, 200, "application/json", out[0], null);
        } catch (Exception ignored) {
            try { sock.close(); } catch (IOException ignored2) { }
        }
    }

    /** Streams a recording file to a linked TV, with byte ranges so it can skip and rewind. */
    private void serveRecording(java.net.Socket sock, String id, String range, String method) throws IOException {
        JSONObject r = id == null || id.isEmpty() ? null : RecordService.Store.get(this, id);
        File f = r == null ? null : new File(r.optString("file"));
        if (f == null || !f.isFile()) {
            sendHttp(sock, 404, "text/plain", "That recording isn't on this TV any more", null);
            return;
        }
        long len = f.length(), from = 0, to = len - 1;
        boolean partial = false;
        if (range.startsWith("bytes=")) {
            String[] se = range.substring(6).split(",")[0].split("-", 2);
            try {
                if (se[0].trim().isEmpty()) {                 // the last N bytes
                    long n = Long.parseLong(se[1].trim());
                    from = Math.max(0, len - n);
                } else {
                    from = Long.parseLong(se[0].trim());
                    if (se.length > 1 && !se[1].trim().isEmpty()) to = Math.min(len - 1, Long.parseLong(se[1].trim()));
                }
                partial = true;
            } catch (NumberFormatException ignored) {
            }
        }
        java.io.OutputStream out = sock.getOutputStream();
        if (from >= len && len > 0) {
            out.write(("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + len + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
            out.flush();
            sock.close();
            return;
        }
        String name = f.getName().toLowerCase(java.util.Locale.ROOT);
        String type = name.endsWith(".ts") ? "video/mp2t" : name.endsWith(".mp4") || name.endsWith(".m4v") ? "video/mp4"
                : name.endsWith(".mkv") ? "video/x-matroska" : "application/octet-stream";
        long count = Math.max(0, to - from + 1);
        StringBuilder h = new StringBuilder();
        h.append(partial ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
        h.append("Content-Type: ").append(type).append("\r\n");
        h.append("Accept-Ranges: bytes\r\n");
        h.append("Content-Length: ").append(count).append("\r\n");
        if (partial) h.append("Content-Range: bytes ").append(from).append('-').append(to).append('/').append(len).append("\r\n");
        h.append("Connection: close\r\n\r\n");
        out.write(h.toString().getBytes("UTF-8"));
        if (!"HEAD".equalsIgnoreCase(method)) {
            sock.setSoTimeout(0);
            try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r")) {
                raf.seek(from);
                byte[] buf = new byte[64 * 1024];
                long left = count;
                while (left > 0) {
                    int n = raf.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n <= 0) break;
                    out.write(buf, 0, n);
                    left -= n;
                }
            } catch (IOException ignored) {
                // the other TV stopped or skipped: it opens a new connection for the new position
            }
        }
        out.flush();
        sock.close();
    }

    private void stopRemote() {
        java.net.ServerSocket ss = remoteSock;
        remoteSock = null;
        if (ss != null) try { ss.close(); } catch (IOException ignored) { }
    }

    private static String queryParam(String query, String name) {
        if (query == null) return "";
        for (String part : query.split("&")) {
            int i = part.indexOf('=');
            if (i > 0 && part.substring(0, i).equals(name)) {
                try { return java.net.URLDecoder.decode(part.substring(i + 1), "UTF-8"); } catch (Exception e) { return ""; }
            }
        }
        return "";
    }

    private void handleRemote(java.net.Socket sock) {
        try {
            sock.setSoTimeout(15000);
            InputStream in = new BufferedInputStream(sock.getInputStream());
            ByteArrayOutputStream head = new ByteArrayOutputStream();
            int b, last4 = 0;
            while ((b = in.read()) != -1) {
                head.write(b);
                last4 = (last4 << 8) | (b & 0xff);
                if (last4 == 0x0d0a0d0a || head.size() > 32768) break;
            }
            String[] lines = head.toString("UTF-8").split("\r\n");
            String[] req = lines.length > 0 ? lines[0].split(" ") : new String[0];
            if (req.length < 2) { sock.close(); return; }
            String method = req[0], target = req[1];
            int len = 0;
            for (String l : lines) {
                int c = l.indexOf(':');
                if (c > 0 && l.substring(0, c).trim().equalsIgnoreCase("content-length")) {
                    try { len = Integer.parseInt(l.substring(c + 1).trim()); } catch (Exception ignored) { }
                }
            }
            if (len > 4 * 1024 * 1024) len = 0;
            byte[] body = new byte[Math.max(0, len)];
            int got = 0;
            while (got < len) { int r = in.read(body, got, len - got); if (r <= 0) break; got += r; }
            String path = target, query = "";
            int q = target.indexOf('?');
            if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }
            if (!remoteKey.equals(queryParam(query, "k"))) {
                sendHttp(sock, 403, "text/plain", "This code has expired. Open the QR code on the TV again.", null);
                return;
            }
            if ("GET".equals(method) && ("/".equals(path) || "/index.html".equals(path))) {
                sendHttp(sock, 200, "text/html", remoteHtml, null);
            } else if ("GET".equals(method) && "/backup".equals(path)) {
                sendHttp(sock, 200, "application/json", remoteBackup, "attachment; filename=\"nebula-tv-setup.json\"");
            } else if ("POST".equals(method) && "/api".equals(path)) {
                final String text = new String(body, 0, got, "UTF-8");
                final String[] out = {"{\"ok\":false,\"msg\":\"The TV did not answer\"}"};
                final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
                runOnUiThread(() -> {
                    if (web == null) { done.countDown(); return; }
                    web.evaluateJavascript("window.__nebulaRemote ? window.__nebulaRemote(" + JSONObject.quote(text) + ") : ''", v -> {
                        try {
                            Object o = new org.json.JSONTokener(v).nextValue();
                            if (o instanceof String && !((String) o).isEmpty()) out[0] = (String) o;
                        } catch (Exception ignored) {
                        }
                        done.countDown();
                    });
                });
                done.await(8, java.util.concurrent.TimeUnit.SECONDS);
                sendHttp(sock, 200, "application/json", out[0], null);
            } else {
                sendHttp(sock, 404, "text/plain", "Not found", null);
            }
        } catch (Exception ignored) {
            try { sock.close(); } catch (IOException ignored2) { }
        }
    }

    private static void sendHttp(java.net.Socket sock, int status, String type, String body, String disposition) throws IOException {
        byte[] data = body.getBytes("UTF-8");
        String reason = status == 200 ? "OK" : status == 403 ? "Forbidden" : "Not Found";
        StringBuilder h = new StringBuilder();
        h.append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n");
        h.append("Content-Type: ").append(type).append("; charset=utf-8\r\n");
        h.append("Content-Length: ").append(data.length).append("\r\n");
        h.append("Cache-Control: no-store\r\nConnection: close\r\n");
        if (disposition != null) h.append("Content-Disposition: ").append(disposition).append("\r\n");
        h.append("\r\n");
        java.io.OutputStream os = sock.getOutputStream();
        os.write(h.toString().getBytes("UTF-8"));
        os.write(data);
        os.flush();
        sock.close();
    }

    // ---------- channel check ----------

    /**
     * A channel only counts as working if real video arrives: MPEG-TS packets (0x47 every 188 bytes),
     * or an HLS playlist whose first segment downloads as video. Error pages, empty playlists and
     * servers that answer but send nothing are treated as broken.
     */
    private void probeStream(String id, String address, String ua) {
        boolean ok = false;
        try {
            ok = probeUrl(address, ua, 0);
        } catch (Exception ignored) {
        }
        final String js = "window.__nebulaProbe && window.__nebulaProbe(" + JSONObject.quote(id) + "," + ok + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private HttpURLConnection probeOpen(String address, String ua) throws IOException {
        String current = address;
        for (int hop = 0; hop < 6; hop++) {
            URL u = new URL(current);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(4000);
            c.setReadTimeout(5000);
            String agent = (ua == null || ua.isEmpty()) ? (userAgent.isEmpty() ? System.getProperty("http.agent") : userAgent) : ua;
            if (agent != null) c.setRequestProperty("User-Agent", agent);
            int st = c.getResponseCode();
            if (st >= 300 && st < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("redirect without address");
                current = new URL(u, loc).toString();
                continue;
            }
            if (st < 200 || st >= 300) {
                c.disconnect();
                throw new IOException("status " + st);
            }
            return c;
        }
        throw new IOException("too many redirects");
    }

    /** Reads up to max bytes, giving up after the time limit. */
    private static int readSome(InputStream in, byte[] buf, int max, long limitMs) throws IOException {
        long end = System.currentTimeMillis() + limitMs;
        int got = 0;
        while (got < max && System.currentTimeMillis() < end) {
            int n = in.read(buf, got, max - got);
            if (n < 0) break;
            got += n;
        }
        return got;
    }

    private static boolean looksLikeTs(byte[] b, int n) {
        for (int off = 0; off < 188 && off + 188 * 3 < n; off++) {
            if (b[off] == 0x47 && b[off + 188] == 0x47 && b[off + 376] == 0x47 && b[off + 564] == 0x47) return true;
        }
        return false;
    }

    private static boolean looksLikeVideo(byte[] b, int n) {
        if (looksLikeTs(b, n)) return true;
        if (n < 12) return false;
        String head = new String(b, 4, 4, java.nio.charset.StandardCharsets.ISO_8859_1);
        if (head.equals("ftyp") || head.equals("moof") || head.equals("styp") || head.equals("sidx")) return true;  // fMP4 / CMAF
        if ((b[0] & 0xFF) == 0xFF && (b[1] & 0xF0) == 0xF0) return true;  // AAC audio-only segment
        if (b[0] == 'I' && b[1] == 'D' && b[2] == '3') return true;  // ID3-tagged audio segment
        return false;
    }

    private boolean probeUrl(String address, String ua, int depth) throws IOException {
        if (depth > 3) return false;
        HttpURLConnection c = probeOpen(address, ua);
        String finalUrl = c.getURL().toString();
        String ct = c.getContentType() == null ? "" : c.getContentType().toLowerCase(java.util.Locale.ROOT);
        byte[] buf = new byte[64 * 1024];
        int n = 0;
        // read only as much as needed: a whole playlist (they are small), or the first few video packets
        try (InputStream in = c.getInputStream()) {
            long end = System.currentTimeMillis() + 5000;
            boolean playlist = ct.contains("mpegurl");
            while (n < buf.length && System.currentTimeMillis() < end) {
                int r = in.read(buf, n, buf.length - n);
                if (r < 0) break;
                n += r;
                if (n >= 7 && !playlist) playlist = new String(buf, 0, 7, java.nio.charset.StandardCharsets.ISO_8859_1).equals("#EXTM3U");
                if (!playlist && n >= 188 * 8) break;
            }
        } finally {
            c.disconnect();
        }
        if (n <= 0) return false;
        String start = new String(buf, 0, Math.min(n, 16), java.nio.charset.StandardCharsets.ISO_8859_1).trim();
        if (start.startsWith("#EXTM3U") || ct.contains("mpegurl")) {
            String text = new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8);
            String next = null;
            boolean master = text.contains("#EXT-X-STREAM-INF");
            boolean afterTag = false;
            for (String raw : text.split("\n")) {
                String l = raw.trim();
                if (l.isEmpty()) continue;
                if (l.startsWith("#EXT-X-STREAM-INF") || l.startsWith("#EXTINF")) { afterTag = true; continue; }
                if (!l.startsWith("#") && afterTag) { next = l; break; }
            }
            if (next == null) return false;  // empty playlist: nothing is being broadcast
            String target = new URL(new URL(finalUrl), next).toString();
            if (master) return probeUrl(target, ua, depth + 1);
            HttpURLConnection s = probeOpen(target, ua);
            try (InputStream in = s.getInputStream()) {
                int m = readSome(in, buf, 2048, 5000);
                return looksLikeVideo(buf, m);
            } finally {
                s.disconnect();
            }
        }
        if (ct.contains("text/html") || start.startsWith("<")) return false;  // an error or login page
        return n >= 188 * 4 && looksLikeVideo(buf, n);
    }

    // ---------- app updates ----------

    private void emitUpdate(String type, String json) {
        final String js = "window.__nebulaUpdate && window.__nebulaUpdate('" + type + "'," + (json == null ? "null" : json) + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void downloadUpdate(String address) {
        try {
            java.io.File dir = Build.VERSION.SDK_INT >= 24 ? new java.io.File(getCacheDir(), "updates") : getExternalFilesDir("updates");
            if (dir == null) throw new IOException("No storage for the download");
            if (!dir.exists()) dir.mkdirs();
            final java.io.File f = new java.io.File(dir, "NebulaTV.apk");
            String current = address;
            HttpURLConnection c = null;
            for (int hop = 0; hop < 8; hop++) {
                URL u = new URL(current);
                c = (HttpURLConnection) u.openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "NebulaTV");
                int st = c.getResponseCode();
                if (st >= 300 && st < 400) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null) throw new IOException("Bad redirect");
                    current = new URL(u, loc).toString();
                    c = null;
                    continue;
                }
                if (st != 200) throw new IOException("Server replied HTTP " + st);
                break;
            }
            if (c == null) throw new IOException("Too many redirects");
            long total = c.getContentLength();
            InputStream in = new BufferedInputStream(c.getInputStream(), 65536);
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            byte[] buf = new byte[65536];
            long n = 0;
            int r, last = -1;
            while ((r = in.read(buf)) > 0) {
                out.write(buf, 0, r);
                n += r;
                if (total > 0) {
                    int pct = (int) (n * 100 / total);
                    if (pct / 5 != last / 5) { last = pct; emitUpdate("progress", String.valueOf(pct)); }
                }
            }
            out.close();
            in.close();
            c.disconnect();
            if (n < 100000) throw new IOException("The download looks incomplete");
            if (Build.VERSION.SDK_INT < 24) f.setReadable(true, false);
            runOnUiThread(() -> launchInstall(f));
        } catch (Exception ex) {
            String m = ex.getMessage();
            emitUpdate("error", JSONObject.quote(m == null ? ex.getClass().getSimpleName() : m));
        }
    }

    private void launchInstall(java.io.File f) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                emitUpdate("permission", null);
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {
                }
                return;
            }
            Uri uri = Build.VERSION.SDK_INT >= 24 ? FileProvider.getUriForFile(this, getPackageName() + ".files", f) : Uri.fromFile(f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            emitUpdate("ready", null);
        } catch (Exception ex) {
            String m = ex.getMessage();
            emitUpdate("error", JSONObject.quote(m == null ? ex.getClass().getSimpleName() : m));
        }
    }

    private String buildTracks(Tracks tracks) {
        JSONArray out = new JSONArray();
        try {
            List<Tracks.Group> groups = tracks.getGroups();
            for (int g = 0; g < groups.size(); g++) {
                Tracks.Group group = groups.get(g);
                int type = group.getType();
                if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_VIDEO && type != C.TRACK_TYPE_TEXT) continue;
                for (int i = 0; i < group.length; i++) {
                    Format f = group.getTrackFormat(i);
                    JSONObject o = new JSONObject();
                    o.put("type", type);
                    o.put("g", g);
                    o.put("i", i);
                    o.put("label", f.label == null ? "" : f.label);
                    o.put("lang", f.language == null ? "" : f.language);
                    o.put("h", f.height);
                    o.put("br", f.bitrate);
                    o.put("ch", f.channelCount);
                    o.put("mime", f.sampleMimeType == null ? "" : f.sampleMimeType);
                    o.put("sel", group.isTrackSelected(i));
                    o.put("sup", group.isTrackSupported(i));
                    out.put(o);
                }
            }
        } catch (Exception ignored) {
        }
        return out.toString();
    }

    private void selectTrack(int type, int g, int i) {
        if (player == null) return;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if (i < 0) {
            b.clearOverridesOfType(type);
            b.setTrackTypeDisabled(type, type == C.TRACK_TYPE_TEXT);
        } else {
            List<Tracks.Group> groups = player.getCurrentTracks().getGroups();
            if (g < 0 || g >= groups.size()) return;
            b.setTrackTypeDisabled(type, false);
            b.setOverrideForType(new TrackSelectionOverride(groups.get(g).getMediaTrackGroup(), i));
        }
        player.setTrackSelectionParameters(b.build());
    }

    private boolean isTelevision() {
        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        PackageManager pm = getPackageManager();
        return pm.hasSystemFeature("android.software.leanback")
                || pm.hasSystemFeature("amazon.hardware.fire_tv");
    }

    /** Methods callable from JavaScript as window.NebulaNative.* */
    private boolean isLite() {
        return getPackageName().endsWith(".lite");
    }

    private String linkScheme() {
        return isLite() ? "nebulatvlite" : "nebulatv";
    }

    private class Bridge {

        @JavascriptInterface
        public void fetchText(final int id, final String url, final String ua) {
            pool.execute(() -> {
                boolean ok = true;
                String message;
                try {
                    String body = download(url, ua);
                    results.put(id, body);
                    message = String.valueOf(body.length());
                } catch (Exception ex) {
                    ok = false;
                    String m = ex.getMessage();
                    message = (m == null || m.isEmpty()) ? ex.getClass().getSimpleName() : m;
                    if (ex instanceof java.net.UnknownHostException) message = "Couldn't find that server — check the address";
                    if (ex instanceof java.net.SocketTimeoutException) message = "The server took too long to answer";
                }
                final String js = "window.__nebulaFetchDone && window.__nebulaFetchDone(" + id + "," + ok + "," + JSONObject.quote(message) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            });
        }

        /** Returns the next piece of a finished download, starting at character `start`. */
        @JavascriptInterface
        public String takeChunk(int id, int start) {
            String s = results.get(id);
            if (s == null || start >= s.length()) return "";
            int end = Math.min(s.length(), start + CHUNK);
            if (end < s.length() && Character.isHighSurrogate(s.charAt(end - 1))) end--;
            return s.substring(start, end);
        }

        @JavascriptInterface
        public void release(int id) {
            results.remove(id);
        }

        @JavascriptInterface
        public void setUserAgent(final String ua) {
            userAgent = ua == null ? "" : ua.trim();
            runOnUiThread(() -> web.getSettings().setUserAgentString(userAgent.isEmpty() ? null : userAgent));
        }

        @JavascriptInterface
        public void nativePlay(final String url, final boolean live, final String ua, final double resumeMs, final String fit, final String type, final int bufferSecs) {
            runOnUiThread(() -> startPlayer(url, live, ua, (long) resumeMs, fit, type, bufferSecs));
        }

        @JavascriptInterface
        public void previewPlay(final String url, final double x, final double y, final double w, final double h, final double scale, final String ua, final boolean muted, final String type, final double radius) {
            runOnUiThread(() -> startPreview(url, x, y, w, h, scale, ua, muted, type, radius));
        }

        @JavascriptInterface
        public void previewMove(final double x, final double y, final double w, final double h, final double scale) {
            runOnUiThread(() -> { if (previewBox.getVisibility() == View.VISIBLE) placePreview(x, y, w, h, scale); });
        }

        @JavascriptInterface
        public void multiPlay(final int i, final String url, final double x, final double y, final double w, final double h, final double scale, final String ua, final boolean muted, final String type) {
            runOnUiThread(() -> startSlot(i, url, x, y, w, h, scale, ua, muted, type));
        }

        @JavascriptInterface
        public void multiMove(final int i, final double x, final double y, final double w, final double h, final double scale) {
            runOnUiThread(() -> { Slot s = slots.get(i); if (s != null) placeBox(s.box, x, y, w, h, scale); });
        }

        @JavascriptInterface
        public void multiAudio(final int focus) {
            runOnUiThread(() -> {
                for (java.util.Map.Entry<Integer, Slot> e : slots.entrySet()) {
                    if (e.getValue().player != null) e.getValue().player.setVolume(e.getKey() == focus ? 1f : 0f);
                }
            });
        }

        @JavascriptInterface
        public void multiVisible(final boolean visible) {
            runOnUiThread(() -> {
                for (Slot s : slots.values()) s.box.setVisibility(visible && s.player != null ? View.VISIBLE : View.GONE);
            });
        }

        @JavascriptInterface
        public void multiStop(final int i) {
            runOnUiThread(() -> stopSlot(i));
        }

        @JavascriptInterface
        public void multiStopAll() {
            runOnUiThread(MainActivity.this::stopAllSlots);
        }

        @JavascriptInterface
        public void previewStop() {
            runOnUiThread(() -> stopPreview(true));
        }

        @JavascriptInterface
        public void nativeStop() {
            runOnUiThread(() -> { tsStop(); releasePlayer(); });
        }

        /** Buffer settings: how many minutes to keep and the most space to use. */
        @JavascriptInterface
        public void tsConfig(final double minutes, final double megabytes) {
            tsMaxMs = (long) (Math.max(5, Math.min(240, minutes)) * 60_000L);
            tsMaxBytes = (long) (Math.max(256, Math.min(16384, megabytes))) << 20;
        }

        /** Plays a live channel through the buffer from the start, so it can be paused and rewound any time. */
        @JavascriptInterface
        public void tsPlay(final String url, final String ua, final String fit, final String type, final int bufferSecs) {
            runOnUiThread(() -> {
                tsStop();
                tsUa = ua == null ? "" : ua;
                tsFit = fit;
                tsBufSecs = bufferSecs;
                tsEnsure(url, tsUa, type);
                tsPlayFrom(System.currentTimeMillis(), true);
            });
        }

        /** Pauses live TV. Without a buffer running, this stops the stream and starts buffering from here. */
        @JavascriptInterface
        public void tsPause(final String url, final String ua, final String fit, final String type, final int bufferSecs) {
            runOnUiThread(() -> {
                if (player == null) return;
                if (tsPlaying && tshift != null) {
                    player.setPlayWhenReady(false);
                    return;
                }
                tsUa = ua == null ? "" : ua;
                tsFit = fit;
                tsBufSecs = bufferSecs;
                if (playerView != null) playerView.setKeepContentOnPlayerReset(true);   // keep the paused picture
                player.stop();   // frees the provider connection for the buffer
                tsEnsure(url, tsUa, type);
                tsPausedAt = System.currentTimeMillis();
            });
        }

        @JavascriptInterface
        public void tsResume() {
            runOnUiThread(() -> {
                if (tshift == null) return;
                if (tsPausedAt > 0) tsPlayFrom(tsPausedAt, true);
                else if (player != null) player.setPlayWhenReady(true);
            });
        }

        /** Moves back (negative) or forward through the buffer; past the live edge plays live. */
        @JavascriptInterface
        public void tsSeek(final double ms) {
            runOnUiThread(() -> {
                if (tshift == null) return;
                long now = System.currentTimeMillis();
                boolean playing = tsPausedAt == 0 && player != null && player.getPlayWhenReady();
                long target = tsWallNow() + (long) ms;
                target = Math.max(tshift.earliestWall(), Math.min(now - 3000, target));
                if (tsPausedAt > 0 && ms < 0 && target <= tshift.earliestWall()) { tsPausedAt = tshift.earliestWall(); return; }
                tsPlayFrom(target, playing);
            });
        }

        @JavascriptInterface
        public void tsLive() {
            runOnUiThread(() -> { if (tshift != null) tsPlayFrom(System.currentTimeMillis() - 3000, true); });
        }

        /** Crashes noted since the error log last asked, oldest first; empty when there were none. */
        /** Box volume from the phone remote: 1 louder, -1 quieter, 0 mute on/off. Returns "level/max". */
        @JavascriptInterface
        public String volume(final int dir) {
            final android.media.AudioManager am = (android.media.AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return "";
            runOnUiThread(() -> {
                int flag = android.media.AudioManager.FLAG_SHOW_UI;
                int st = android.media.AudioManager.STREAM_MUSIC;
                if (dir == 0) {
                    if (Build.VERSION.SDK_INT >= 23) am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_TOGGLE_MUTE, flag);
                    else { volMuted = !volMuted; am.setStreamMute(st, volMuted); }
                } else {
                    am.adjustStreamVolume(st, dir > 0 ? android.media.AudioManager.ADJUST_RAISE : android.media.AudioManager.ADJUST_LOWER, flag);
                }
            });
            int st = android.media.AudioManager.STREAM_MUSIC;
            int now = am.getStreamVolume(st) + (dir > 0 ? 1 : dir < 0 ? -1 : 0);
            return Math.max(0, Math.min(am.getStreamMaxVolume(st), now)) + "/" + am.getStreamMaxVolume(st);
        }

        @JavascriptInterface
        public String takeCrashes() {
            return CrashNote.take(getApplicationContext());
        }

        @JavascriptInterface
        public String sysInfo() {
            final String[] out = {"{}"};
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(() -> { out[0] = sysJson(); done.countDown(); });
            try { done.await(500, java.util.concurrent.TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
            return out[0];
        }

        @JavascriptInterface
        public String tsInfo() {
            final String[] out = {"null"};
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(() -> { out[0] = tsState(); done.countDown(); });
            try { done.await(500, java.util.concurrent.TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
            return out[0];
        }

        @JavascriptInterface
        public void nativeToggle() {
            runOnUiThread(() -> { if (player != null) player.setPlayWhenReady(!player.getPlayWhenReady()); });
        }

        @JavascriptInterface
        public void nativeSeekBy(final double ms) {
            runOnUiThread(() -> {
                if (player == null) return;
                long t = Math.max(0, player.getCurrentPosition() + (long) ms);
                long d = player.getDuration();
                if (d != C.TIME_UNSET && d > 0) t = Math.min(t, d - 1000);
                player.seekTo(t);
            });
        }

        @JavascriptInterface
        public void nativeSetFit(final String fit) {
            runOnUiThread(() -> applyFit(fit));
        }

        @JavascriptInterface
        public void nativeSetRate(final double rate) {
            runOnUiThread(() -> { if (player != null) player.setPlaybackSpeed((float) rate); });
        }

        @JavascriptInterface
        public String nativeTracks() {
            return tracksJson;
        }

        @JavascriptInterface
        public void nativeSelectTrack(final int type, final int g, final int i) {
            runOnUiThread(() -> selectTrack(type, g, i));
        }

        @JavascriptInterface
        public boolean vpnActive() {
            try {
                android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                if (cm != null && Build.VERSION.SDK_INT >= 23) {
                    for (android.net.Network n : cm.getAllNetworks()) {
                        android.net.NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                        if (nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN)) return true;
                    }
                    return false;
                }
                for (java.net.NetworkInterface ni : java.util.Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                    String n = ni.getName() == null ? "" : ni.getName();
                    if (ni.isUp() && (n.startsWith("tun") || n.startsWith("ppp") || n.startsWith("wg"))) return true;
                }
            } catch (Exception ignored) {
            }
            return false;
        }

        @JavascriptInterface
        public boolean openApp(final String pkg) {
            try {
                PackageManager pm = getPackageManager();
                Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
                if (i == null) i = pm.getLaunchIntentForPackage(pkg);
                if (i == null) return false;
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                final Intent go = i;
                runOnUiThread(() -> { try { startActivity(go); } catch (Exception ignored) { } });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String remoteStart(String key, String html, String backup) {
            return startRemote(key, html, backup);
        }

        @JavascriptInterface
        public void remoteStop() {
            stopRemote();
        }

        @JavascriptInterface
        public String localIp() {
            return MainActivity.localIp();
        }

        @JavascriptInterface
        public void probe(final String id, final String url, final String ua) {
            probePool.execute(() -> probeStream(id, url, ua));
        }

        @JavascriptInterface
        public boolean openExternal(final String url) {
            try {
                final Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (getPackageManager().resolveActivity(i, 0) == null) return false;
                runOnUiThread(() -> { try { startActivity(i); } catch (Exception ignored) { } });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void nativePrefs(final String audio, final boolean subs) {
            prefAudio = audio == null ? "" : audio.trim();
            prefSubs = subs;
            runOnUiThread(MainActivity.this::applyPrefs);   // so a change takes effect on what's playing
        }

        @JavascriptInterface
        public String nativeStats() {
            final String[] out = {"null"};
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(() -> { out[0] = statsJson(); done.countDown(); });
            try { done.await(500, java.util.concurrent.TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
            return out[0];
        }

        @JavascriptInterface
        public void speedTest(final String url) {
            pool.execute(() -> runSpeedTest(url));
        }

        @JavascriptInterface
        public void updateInstall(final String url) {
            pool.execute(() -> downloadUpdate(url));
        }

        @JavascriptInterface
        public void nativeMini(final double x, final double y, final double w, final double h, final double scale, final double radius) {
            runOnUiThread(() -> setMini(x, y, w, h, scale, radius));
        }

        @JavascriptInterface
        public void voiceSearch() {
            runOnUiThread(MainActivity.this::startVoice);
        }

        @JavascriptInterface
        public void homeRows(final String json) {
            pool.execute(() -> publishHomeRows(json));
        }

        @JavascriptInterface
        public String takeLink() {
            String l = pendingLink;
            pendingLink = "";
            return "home".equals(l) ? "" : l;
        }

        @JavascriptInterface
        public void nativeSubStyle(final double size, final String fg, final String bg, final String edge) {
            ui.post(() -> applySubStyle(size, fg, bg, edge));
        }

        @JavascriptInterface
        public boolean audioFxSupported() {
            return Build.VERSION.SDK_INT >= 28;
        }

        @JavascriptInterface
        public void nativeAudioMode(final String mode) {
            audioMode = mode == null ? "off" : mode;
            ui.post(() -> { try { applyAudioMode(player == null ? 0 : player.getAudioSessionId()); } catch (Exception ignored) { } });
        }

        @JavascriptInterface
        public String linkStart(String key) {
            return startLink(key);
        }

        @JavascriptInterface
        public void nativePip(final boolean on) {
            pipAllowed = on;
        }

        @JavascriptInterface
        public String recAdd(String json) {
            try {
                JSONObject o = new JSONObject(json);
                if (o.optString("id").isEmpty()) o.put("id", "r" + System.currentTimeMillis() + (int) (Math.random() * 1000));
                o.put("status", "scheduled");
                o.put("created", System.currentTimeMillis());
                RecordService.Store.put(getApplicationContext(), o);
                RecordService.schedule(getApplicationContext(), o);
                return o.getString("id");
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void recStop(String id) {
            Context c = getApplicationContext();
            JSONObject o = RecordService.Store.get(c, id);
            if (o == null) return;
            if ("recording".equals(o.optString("status")) && RecordService.active.contains(id)) RecordService.stop(c, id);
            else {
                RecordService.cancelAlarm(c, id);
                if ("scheduled".equals(o.optString("status"))) RecordService.Store.update(c, id, "status", "cancelled");
            }
        }

        @JavascriptInterface
        public void recDelete(String id) {
            Context c = getApplicationContext();
            JSONObject o = RecordService.Store.get(c, id);
            RecordService.stop(c, id);
            if (o != null && !o.optString("file").isEmpty()) {
                final java.io.File f = new java.io.File(o.optString("file"));
                // give a running recording a moment to close the file first
                ui.postDelayed(() -> { try { f.delete(); } catch (Exception ignored) { } }, RecordService.active.contains(id) ? 3000 : 0);
            }
            RecordService.Store.remove(c, id);
        }

        @JavascriptInterface
        public String recList() {
            JSONArray a = RecordService.Store.all(getApplicationContext());
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                try {
                    String f = o.optString("file");
                    if (!f.isEmpty()) {
                        java.io.File file = new java.io.File(f);
                        o.put("size", file.exists() ? file.length() : 0);
                        o.put("exists", file.exists());
                    }
                    o.put("live", RecordService.active.contains(o.optString("id")));
                } catch (Exception ignored) {
                }
            }
            return a.toString();
        }

        @JavascriptInterface
        public String recStorage() {
            return RecordService.storageJson(getApplicationContext()).toString();
        }

        @JavascriptInterface
        public void recSetDir(int i) {
            getSharedPreferences("nebula_rec", Context.MODE_PRIVATE).edit().putInt("dir", i).apply();
        }

        @JavascriptInterface
        public String edition() {
            return isLite() ? "lite" : "full";
        }

        @JavascriptInterface
        public boolean isTv() {
            return isTelevision();
        }

        @JavascriptInterface
        public String appVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String platform() {
            return "android " + Build.VERSION.RELEASE;
        }
    }
}
